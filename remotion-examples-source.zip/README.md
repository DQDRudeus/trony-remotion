# Trony Remotion examples / 视频动效示例

Install Node.js 22 or 24 and npm. Open a terminal in this directory, run `npm ci`, then `npm run studio:thief` to start Remotion Studio. Select a composition below. 在本目录安装依赖并启动 Studio，选择合成即可逐帧预览和修改。

| Video / 成片 | Composition | Start editing / 源码 |
| --- | --- | --- |
| xiaolin-pack.mp4 | XiaolinPack | src/Studio.tsx, FilmScenes.tsx, Extras.tsx, RouteScene.tsx, PaperScene.tsx |
| trony-paper.mp4 | PaperInsert | src/TronyPaper.tsx, public/paper/trony-post.png |
| thief-code.mp4 | ThiefCode | src/ThiefCode.tsx, public/thief/ |

Render the full showcase with `npx remotion render src/index.ts XiaolinPack out/xiaolin-pack.mp4`. For the paper or thief use `npm run render:paper` or `npm run render:thief`. Transparent exports are available via `npm run render:paper-alpha` and `npm run render:thief-alpha`.

原创示例代码与文档按 MIT 许可提供。素材随示例提供，第三方依赖、媒体中的第三方内容及字体按各自条款使用。Original example source code and documentation use the MIT License. Third-party content, fonts and software (including Remotion) retain their respective terms.
