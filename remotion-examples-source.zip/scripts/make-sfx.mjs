import {mkdirSync, writeFileSync} from 'node:fs';

// Three short original Foley cues; render the exact same transients on every run.
const folder = new URL('../public/sfx/', import.meta.url);
mkdirSync(folder, {recursive: true});
const sampleRate = 48000;
let seed = 47;
let previousNoise = 0;
function transient(t, onset, decay, tone) {
  const local = t - onset;
  if (local < 0) return 0;
  seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
  const noise = seed / 2147483648 - 1;
  const high = noise - 0.72 * previousNoise;
  previousNoise = noise;
  return (0.53 * high + 0.47 * Math.sin(2 * Math.PI * tone * local)) *
    Math.min(1, local * 3500) * Math.exp(-local / decay);
}
function writeCue(name, duration, signal) {
  const count = Math.ceil(duration * sampleRate);
  const data = Buffer.alloc(44 + count * 2);
  data.write('RIFF'); data.writeUInt32LE(data.length - 8, 4); data.write('WAVEfmt ', 8);
  data.writeUInt32LE(16, 16); data.writeUInt16LE(1, 20); data.writeUInt16LE(1, 22);
  data.writeUInt32LE(sampleRate, 24); data.writeUInt32LE(sampleRate * 2, 28);
  data.writeUInt16LE(2, 32); data.writeUInt16LE(16, 34); data.write('data', 36);
  data.writeUInt32LE(count * 2, 40);
  for (let i = 0; i < count; i++) {
    const t = i / sampleRate;
    const taper = Math.min(1, (count - i) / 220);
    data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, signal(t))) * taper * 26000), 44 + i * 2);
  }
  writeFileSync(new URL(name + '.wav', folder), data);
}
writeCue('photo', .22, t => transient(t, 0, .011, 940) + .62 * transient(t, .048, .017, 550) + .13 * transient(t, .092, .010, 1400));
writeCue('cut', .105, t => .85 * transient(t, 0, .0075, 1430) + .15 * transient(t, .019, .012, 770));
writeCue('pop', .24, t => {
  const phase = 2 * Math.PI * (140 * t + 470 * .035 * (1 - Math.exp(-t / .035)));
  return Math.min(1, t * 750) * Math.exp(-t / .041) * (.86 * Math.sin(phase) + .14 * Math.sin(2 * phase));
});
