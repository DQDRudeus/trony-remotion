import {mkdirSync} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';

// Windows sandbox temp paths may contain !, which Webpack rejects as loader syntax.
const require = createRequire(import.meta.url);
const temp = resolve('.remotion/thief-temp');
mkdirSync(temp, {recursive: true});
const cli = join(dirname(require.resolve('@remotion/cli/package.json')), 'remotion-cli.js');
const result = spawnSync(process.execPath, [cli, ...process.argv.slice(2)], {
  stdio: 'inherit', env: {...process.env, TEMP: temp, TMP: temp, TMPDIR: temp}, windowsHide: true,
});
if (result.error) console.error(result.error.message);
process.exit(result.status ?? 1);
