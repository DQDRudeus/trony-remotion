import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Sound} from './FilmScenes';

export const thiefDefaults = {
  title: '小偷', english: 'thief', effort: '两晚上的努力',
  upperLabel: '模仿', lowerLabel: '开源',
  revealAt: 60, mimicCue: 150, openCue: 224,
  sound: true, sideView: true, transparentBackground: false,
};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = (f: number, a: number, b: number) => {
  const t = interpolate(f, [a, b], [0, 1], clamp);
  return t * t * (3 - 2 * t);
};
const sans = '"Microsoft YaHei", sans-serif';
const mono = '"Consolas", monospace';
const gold = '#e8e1b9';

const MetalText: React.FC<{children: React.ReactNode; size: number; style?: React.CSSProperties}> = ({children, size, style}) => (
  <div style={{fontFamily: sans, fontWeight: 900, fontSize: size, lineHeight: 1.16,
    color: '#ecece3', transform: 'skewX(-9deg)', letterSpacing: 5,
    filter: 'drop-shadow(3px 5px 0 #303a37) drop-shadow(0 9px 12px #000b)', ...style}}>
    <span style={{background: 'linear-gradient(175deg,#ffffed 8%,#e7e9df 32%,#7e8985 58%,#c3cac5 70%,#6b7773 96%)', backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>{children}</span>
  </div>
);

const Frame: React.FC<{children: React.ReactNode; style?: React.CSSProperties; active?: number}> = ({children, style, active = 0}) => (
  <div style={{position: 'absolute', borderRadius: 29, border: '2px solid #dfdfbc',
    background: 'linear-gradient(140deg,#b1b89565,#141f1b 5%,#060d11 58%,#7e856252)',
    padding: 12, boxSizing: 'border-box',
    boxShadow: `0 0 0 12px #bac39b09,0 0 0 23px #abb48e04,0 30px 65px #000b,0 0 ${22 + active * 30}px #d8d6a633,inset 0 0 14px #f3edc76b`, ...style}}>
    <div style={{position: 'absolute', inset: 12, border: '2px dotted #dbdab16b', borderRadius: 18, pointerEvents: 'none', zIndex: 8}}/>
    <div style={{position: 'absolute', inset: 20, borderRadius: 13, overflow: 'hidden', background: '#071113'}}>{children}</div>
  </div>
);

const CodeFlow: React.FC<{frame: number; start: number; y: number; label: string; color: string; reverse?: boolean; focus: number}> = ({frame, start, y, label, color, reverse = false, focus}) => {
  const t = ease(frame, start, start + 28);
  const offset = ((frame - start) * (reverse ? -1.7 : 1.7)) % 76;
  return <div style={{position: 'absolute', left: 552, top: y, width: 380, height: 134, opacity: t * (.58 + focus * .42)}}>
    <div style={{position: 'absolute', left: 55, top: -58, color: '#e7e8da', fontFamily: sans,
      fontWeight: 700, fontSize: 35, letterSpacing: 6, transform: 'skewX(-8deg)',
      textShadow: `0 3px 8px #000,0 0 ${focus * 20}px ${color}`}}>{label}</div>
    <div style={{position: 'absolute', inset: '0 0 20px', overflow: 'hidden', clipPath: `inset(0 ${100 * (1 - t)}% 0 0)`,
      maskImage: 'linear-gradient(90deg,transparent,#000 6%,#000 90%,transparent)', filter: `drop-shadow(0 0 ${5 + focus * 7}px ${color}88)`}}>
      {[0, 1].map(row => <div key={row} style={{display: 'flex', gap: 8, position: 'absolute', top: row * 45, left: -160 + offset}}>
        {Array.from({length: 11}, (_, i) => <div key={i} style={{width: 68, height: 34, flexShrink: 0, borderRadius: 7,
          border: `1px solid ${color}b0`, background: `linear-gradient(140deg,${color}b8,${color}4d)`,
          boxShadow: `inset 0 1px 4px #ffffff52,0 4px 8px #0009`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#071b16', fontFamily: mono, fontSize: 24, fontWeight: 900}}>{['</>', '{ }', '( )', '=>'][i % 4]}</div>)}
      </div>)}
    </div>
    <div style={{position: 'absolute', top: -9, left: 340 * ease(frame, start, start + 45), width: 7, height: 96, borderRadius: 8, background: color, filter: 'blur(5px)', opacity: Math.sin(t * Math.PI) * .8}}/>
  </div>;
};

const LiquidOrb: React.FC<{frame: number}> = ({frame: f}) => {
  const points = Array.from({length: 16}, (_, i) => {
    const a = i / 16 * Math.PI * 2;
    const wave = 1 + .055 * Math.sin(f / 23 + i * 1.7) + .035 * Math.sin(f / 41 - i * 2.1);
    return [410 + Math.cos(a) * 325 * wave, 330 + Math.sin(a) * 278 * wave];
  });
  const middle = (a: number[], b: number[]) => `${(a[0]+b[0])/2},${(a[1]+b[1])/2}`;
  const path = `M${middle(points[15],points[0])} ` + points.map((p,i) => `Q${p[0]},${p[1]} ${middle(p,points[(i+1)%16])}`).join(' ') + ' Z';
  return <svg viewBox="0 0 820 660" style={{position:'absolute',inset:0,width:'100%',height:'100%',opacity:.75}}>
    <defs>
      <radialGradient id="thief-orb" cx="34%" cy="23%" r="80%">
        <stop offset="0" stopColor="#a7d5be" stopOpacity=".12"/><stop offset=".52" stopColor="#134a40" stopOpacity=".08"/>
        <stop offset=".83" stopColor="#275c52" stopOpacity=".24"/><stop offset=".97" stopColor="#7da891" stopOpacity=".44"/><stop offset="1" stopColor="#b0dbc0" stopOpacity=".65"/>
      </radialGradient>
      <linearGradient id="thief-rim" x2="1" y2="1"><stop stopColor="#cceacc" stopOpacity=".6"/><stop offset=".35" stopColor="#2f816e" stopOpacity=".1"/><stop offset="1" stopColor="#72c0ac" stopOpacity=".5"/></linearGradient>
      <clipPath id="thief-orb-clip"><path d={path}/></clipPath>
    </defs>
    <path d={path} fill="url(#thief-orb)" stroke="url(#thief-rim)" strokeWidth="3"/>
    <g clipPath="url(#thief-orb-clip)">
      {Array.from({length:20},(_,i) => {
        const x=130+(i*131)%560+Math.sin(f/38+i*2)*25;
        const y=100+((i*97-f*(.3+i%3*.16))%480+480)%480;
        return <text key={i} x={x} y={y} transform={`rotate(${Math.sin(f/50+i)*30} ${x} ${y})`} fill={i%2?'#bed1bf':'#a8e9c8'}
          opacity={.1+i%4*.035} fontFamily={mono} fontSize={28+i%4*13}>{['{}','</>','=>','( )'][i%4]}</text>;
      })}
    </g>
    <path d={path} fill="none" stroke="#d3e1b6" strokeOpacity=".13" strokeWidth="10" strokeDasharray="60 1700" strokeDashoffset={-f*2.5}/>
  </svg>;
};

export const ThiefCode: React.FC<typeof thiefDefaults> = ({title, english, effort, upperLabel, lowerLabel, revealAt, mimicCue, openCue, sound, sideView, transparentBackground}) => {
  const f = useCurrentFrame();
  const entry = ease(f, 0, 25);
  const spread = ease(f, revealAt, revealAt + 35);
  const right = ease(f, revealAt + 5, revealAt + 38);
  const mimicFocus = ease(f, mimicCue, mimicCue + 12) * (1 - ease(f, openCue - 14, openCue));
  const openFocus = ease(f, openCue, openCue + 14);
  const side = sideView ? ease(f, 280, 340) : 0;
  const zoom = 1 + .027 * ease(f, 125, 175) + .018 * ease(f, 220, 265);
  const effortChars = Array.from(effort);

  return <AbsoluteFill style={{background: transparentBackground ? 'transparent' : '#030b0e', overflow: 'hidden', color: '#eeeddf', fontFamily: sans}}>
    {!transparentBackground && <>
    <AbsoluteFill style={{background: `radial-gradient(ellipse at ${68 + Math.sin(f / 90) * 8}% 30%,#26483c99,transparent 54%),radial-gradient(ellipse at 20% 85%,#17343199,transparent 52%),linear-gradient(130deg,#02080c,#0c211d 65%,#02090e)`}}/>
    <Img src={staticFile('thief/blond-thief.png')} style={{position: 'absolute', width: 1400, left: 700 - f * .3, top: -220 + Math.sin(f / 65) * 18, opacity: .075, filter: 'blur(32px)', transform: 'rotate(-16deg)'}}/>
    {Array.from({length: 24}, (_, i) => <div key={i} style={{position: 'absolute', left: (i * 331 + 53) % 1920, top: ((i * 193 - f * (.15 + i % 3 * .08)) % 1080 + 1080) % 1080,
      font: `${22 + i % 3 * 14}px ${mono}`, color: i % 2 ? '#72957e' : '#d4c591', opacity: .035 + i % 3 * .015,
      transform: `rotate(${-25 + i % 6 * 12}deg)`, filter: 'blur(1px)'}}>{['</>', '{ }', '01', '=>'][i % 4]}</div>)}
    </>}

    <div style={{position: 'absolute', inset: 0, perspective: 2100, perspectiveOrigin: '45% 50%'}}>
      <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d',
        transform: `translateY(${(1 - entry) * 60}px) scale(${(.94 + .06 * entry) * zoom}) rotateY(${-side * 8}deg) rotateX(${side * 2}deg)`, opacity: entry}}>
        {/* Both lanes are below the cards, matching the reference's layered topology. */}
        <CodeFlow frame={f} start={revealAt + 36} y={423} label={upperLabel} color="#f58d64" focus={mimicFocus}/>
        <CodeFlow frame={f} start={revealAt + 66} y={670} label={lowerLabel} color="#8bf5b4" focus={openFocus} reverse/>

        <Frame style={{left: 730 - 625 * spread, top: 205 + 12 * spread, width: 460, height: 650,
          transform: `rotateY(${-7 * spread + 13 * (1 - entry)}deg) translateY(${Math.sin(f / 40) * 2}px)`}} active={mimicFocus * .4}>
          <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 55%,#24392e,transparent 64%),linear-gradient(160deg,#121a17,#02080c)'}}/>
          <AbsoluteFill style={{opacity: .18, backgroundImage: 'repeating-linear-gradient(140deg,transparent 0px,transparent 29px,#a99f6c 30px,transparent 31px)'}}/>
          {[0,1,2].map(i => <div key={i} style={{position: 'absolute', width: 290 - i * 44, height: 290 - i * 44, left: 63 + i * 22, top: 180 + i * 22, borderRadius: '50%', border: '1px dashed #c8c18a3d', transform: `rotate(${f * .11 * (i % 2 ? -1 : 1)}deg) scaleY(1.25)`}}/>)}
          <MetalText size={118} style={{position: 'absolute', top: 20, left: 0, right: 0, textAlign: 'center',
            opacity: ease(f, 8, 38), transform: `skewX(-9deg) translateY(${12 * (1 - ease(f, 8, 38))}px)`,
            maskImage: `linear-gradient(105deg,#000 ${-20 + ease(f, 8, 46) * 145}%,transparent ${ease(f, 8, 46) * 145}%)`}}>{title}</MetalText>
          {[{x:5,y:158,w:94,p:0},{x:310,y:225,w:85,p:2},{x:10,y:451,w:72,p:4},{x:320,y:465,w:70,p:6}].map((c,i)=><Img key={i} src={staticFile('thief/blond-thief.png')}
            style={{position:'absolute',left:c.x,top:c.y+Math.sin(f/26+c.p)*12,width:c.w,opacity:.28+(i%2)*.12,filter:'drop-shadow(0 6px 8px #000a)',transform:`rotate(${Math.sin(f/50+c.p)*5}deg)`}}/>)}
          <Img src={staticFile('thief/blond-thief.png')} style={{position: 'absolute', left: 40, top: 184 + Math.sin(f / 30) * 10, width: 340,
            filter: 'drop-shadow(0 15px 20px #000a)', transform: `scale(${1 + Math.sin(f / 55) * .008})`}}/>
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 80, background: 'linear-gradient(transparent,#07100df0)'}}/>
          <div style={{position: 'absolute', left: 0, right: 0, bottom: 20, textAlign: 'center', fontFamily: mono, fontSize: 38,
            color: '#c9d0bf', letterSpacing: 4, textShadow: '0 4px 5px #000', opacity: ease(f, 20, 44)}}>{english}</div>
          <div style={{position: 'absolute', top: -80, left: -180 + ease(f, 0, 55) * 940, width: 90, height: 1000,
            background: 'linear-gradient(90deg,transparent,#fff8,transparent)', transform: 'rotate(28deg)', opacity: .08}}/>
        </Frame>

        <Frame style={{left: 920 + (1 - right) * 100, top: 190, width: 870, height: 700, opacity: right,
          transform: `rotateY(${(1 - right) * -17}deg) scale(${.96 + right * .04})`}} active={openFocus * .7}>
          <AbsoluteFill style={{background: 'radial-gradient(ellipse at 70% 75%,#1c483c 0%,#0a1b1c 50%,#040c12 100%)'}}/>
          <LiquidOrb frame={f}/>
          <div style={{position: 'absolute', left: -50, top: -90, width: 900, height: 600,
            background: 'radial-gradient(ellipse,#50745b2e,transparent 62%)', transform: `rotate(${f * .08}deg) translateX(${Math.sin(f / 50) * 45}px)`}}/>
          <Img src={staticFile('thief/two-nights.png')} style={{position: 'absolute', width: 810, height: 650, objectFit: 'contain', left: 8, top: 13 + Math.sin(f / 42) * 7,
            opacity: .59, filter: 'drop-shadow(0 20px 24px #000a)', transform: `scale(${1.05 + .035 * ease(f, revealAt, 300)}) rotate(${Math.sin(f/61)*.6}deg)`}}/>
          <AbsoluteFill style={{background: 'linear-gradient(180deg,#030c1050 5%,#030c1070 44%,transparent 83%)'}}/>
          <div style={{position: 'absolute', left: 22, right: 22, top: 138, textAlign: 'center'}}>
            <MetalText size={96} style={{letterSpacing: 4, fontWeight: 700, lineHeight: 1.42,
              filter: 'drop-shadow(2px 3px 0 #495651) drop-shadow(0 7px 6px #000d)'}}>
              {effortChars.map((char, i) => {
                const t = ease(f, revealAt + 15 + i * 4, revealAt + 42 + i * 4);
                return <React.Fragment key={i}>
                  {i === Math.max(1, effortChars.length - 2) && <br/>}
                  <span style={{display: 'inline-block', opacity: t, transform: `translateY(${(1-t)*18}px)`,
                    background: 'linear-gradient(175deg,#fffff3 18%,#cfd8cf 50%,#f0f0d9 64%,#7f9186)', backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>{char}</span>
                </React.Fragment>;
              })}
            </MetalText>
          </div>
          {/* A faint moving screen reflection keeps the illustration alive. */}
          <div style={{position: 'absolute', left: 80, right: 80, bottom: 72, height: 80, borderRadius: '50%',
            background: '#79efb4', filter: 'blur(50px)', opacity: .055 + openFocus * (.06 + Math.sin(f / 8) * .018)}}/>
        </Frame>
      </div>
    </div>
    {/* Animated 2.35:1 cinema matte. */}
    {!transparentBackground && ['top', 'bottom'].map(edge => <div key={edge} style={{position: 'absolute', left: 0, right: 0, [edge]: 0,
      height: 132 * ease(f, 0, 30), background: '#020607', boxShadow: '0 0 32px #0005'}}/>)}
    {sound && <><Sound at={6} kind="photo" volume={.32}/><Sound at={revealAt + 7} kind="pop" volume={.35}/>
      <Sound at={revealAt + 36} kind="cut" volume={.25}/><Sound at={revealAt + 66} kind="cut" volume={.25}/>
      <Sound at={mimicCue} kind="pop" volume={.22}/><Sound at={openCue} kind="pop" volume={.22}/></>}
  </AbsoluteFill>;
};
