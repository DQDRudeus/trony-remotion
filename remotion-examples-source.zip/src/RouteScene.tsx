import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";

export type RouteSceneProps = {
  stations: [string, string, string];
  /** Local composition frames at which each station is reached. */
  cues: [number, number, number];
};

export const routeDefaults: RouteSceneProps = {
  stations: ["杭州东", "嘉兴南", "上海虹桥"],
  cues: [10, 60, 108],
};

const sans = '"Microsoft YaHei", "Noto Sans CJK SC", sans-serif';
const serif = '"STSong", "SimSun", "Noto Serif CJK SC", serif';
const mono = 'Consolas, "Courier New", monospace';
const ivory = "#fcf0d6";
const amber = "#ffbd65";
const clamp = (n: number) => Math.max(0, Math.min(1, n));
const ease = (t: number) => t * t * (3 - 2 * t);
const ramp = (frame: number, from: number, to: number) =>
  ease(clamp((frame - from) / Math.max(1, to - from)));

type Point = readonly [number, number];
type Curve = readonly [Point, Point, Point, Point];
const stops: Point[] = [[185, 400], [559, 277], [926, 151]];
const tracks: Curve[] = [
  [stops[0], [290, 397], [409, 260], stops[1]],
  [stops[1], [682, 290], [792, 168], stops[2]],
];
const linePath = ([p, a, b, q]: Curve) =>
  `M${p.join(" ")} C${a.join(" ")} ${b.join(" ")} ${q.join(" ")}`;
const lines = tracks.map(linePath);

function pointOnTrack(curve: Curve, t: number): Point {
  const [p, a, b, q] = curve;
  const s = 1 - t;
  const coord = (i: 0 | 1) =>
    s ** 3 * p[i] + 3 * s * s * t * a[i] + 3 * s * t * t * b[i] + t ** 3 * q[i];
  return [coord(0), coord(1)];
}

// Map a fraction of the travelled distance to a Bézier parameter, so the
// moving marker meets the end of the SVG stroke even on a tight curve.
const arcLengths = tracks.map((curve) => {
  const samples = [0];
  for (let i = 1; i <= 100; i++) {
    const a = pointOnTrack(curve, (i - 1) / 100);
    const b = pointOnTrack(curve, i / 100);
    samples.push(samples[i - 1] + Math.hypot(b[0] - a[0], b[1] - a[1]));
  }
  return samples.map((n) => n / samples[100]);
});

function trainPosition(segment: number, fraction: number) {
  const samples = arcLengths[segment];
  const next = Math.max(1, samples.findIndex((n) => n >= fraction));
  const previous = next - 1;
  const local = (fraction - samples[previous]) / (samples[next] - samples[previous]);
  const t = clamp((previous + local) / 100);
  const point = pointOnTrack(tracks[segment], t);
  const a = pointOnTrack(tracks[segment], Math.max(0, t - 0.005));
  const b = pointOnTrack(tracks[segment], Math.min(1, t + 0.005));
  return {point, angle: Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI};
}

const bay =
  "M-30 473 C45 443 99 438 151 444 S218 468 268 458 S353 423 393 415 " +
  "S469 420 516 396 S563 364 609 365 S657 361 708 344 " +
  "S818 330 868 308 S919 278 962 287 S1059 349 1131 313 L1200 306 V620 H757 " +
  "C707 536 653 492 593 467 S501 441 453 440 S357 443 308 463 " +
  "S242 481 186 461 S58 448 -30 483Z";
const lake =
  "M349 33 C366 20 377 37 393 31 S424 35 438 44 S459 39 475 53 " +
  "S492 76 477 91 S482 109 463 113 S446 131 425 128 S413 111 393 118 " +
  "S378 104 374 94 S352 89 359 72 S342 49 349 33Z";
const waterways = [
  "M-15 204 Q83 244 120 219 T245 203 Q322 212 370 188 T459 158 L473 108",
  "M-10 333 C84 346 100 305 174 302 S289 344 354 336 S453 305 478 337 S535 364 582 364",
  "M1018 -10 C987 51 929 68 963 113 S996 146 992 197 S1010 225 1007 250 S1023 281 1050 290",
  "M487 -10 Q504 37 491 65 T513 142 Q546 172 541 197 T581 255 Q593 269 586 289",
  "M670 -10 Q629 37 653 82 T662 149 Q654 182 710 198 T775 232 Q801 260 850 252",
  "M259 598 Q246 565 189 547 T120 497 Q106 472 80 457",
];
const roads = [
  "M-25 190 C41 182 129 255 220 247 S330 214 412 235 S555 259 637 218 S741 153 836 137 S986 83 1150 66",
  "M52 595 C73 539 102 455 192 416 S319 345 393 333 S495 315 546 279 S635 208 727 187 S872 152 884 80 L909 -12",
  "M146 -20 C179 60 135 141 202 182 S324 252 326 310 S281 415 295 463 S344 508 345 593",
  "M565 -10 C629 44 604 102 592 142 S575 227 611 251 S684 292 692 346",
  "M802 -10 C747 47 768 96 808 119 S890 171 879 211 S839 254 871 307",
  "M-20 382 Q84 333 154 360 T297 373 Q367 352 410 365 T535 369",
  "M958 269 Q931 228 957 206 T1037 176 Q1102 155 1174 175",
];

const MapDrawing = React.memo(() => (
  <>
    <defs>
      <linearGradient id="rail-map-ink" x1="0" y1="0" x2="1" y2="1" gradientUnits="objectBoundingBox">
        <stop stopColor="#294c4b" /><stop offset=".56" stopColor="#233f40" />
        <stop offset="1" stopColor="#1d3539" />
      </linearGradient>
      <linearGradient id="rail-map-water" x1="0" y1="0" x2="0" y2="1">
        <stop stopColor="#162f36" /><stop offset="1" stopColor="#193942" />
      </linearGradient>
      <pattern id="rail-map-grid" width="67" height="53" patternUnits="userSpaceOnUse">
        <path d="M67 0H0V53" fill="none" stroke="#c6d7ba" strokeWidth=".8" opacity=".13" />
        <path d="M64 0h6M67 -3v6" fill="none" stroke="#e8dbad" opacity=".28" />
      </pattern>
      <pattern id="rail-map-ripples" width="10" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(-23)">
        <path d="M0 .5h10" stroke="#9ec2bc" opacity=".075" />
      </pattern>
      <radialGradient id="rail-map-light">
        <stop stopColor="#ffb54a" stopOpacity=".30" /><stop offset=".5" stopColor="#ffb54a" stopOpacity=".09" />
        <stop offset="1" stopColor="#ffb54a" stopOpacity="0" />
      </radialGradient>
    </defs>
    <rect width="1140" height="580" fill="url(#rail-map-ink)" />
    <rect width="1140" height="580" fill="url(#rail-map-grid)" />
    <g fill="none" strokeLinecap="round">
      {waterways.map((d) => <path key={d} d={d} stroke="#759899" strokeOpacity=".30" strokeWidth="2" />)}
      {roads.map((d) => <path key={d} d={d} stroke="#c5c19c" strokeOpacity=".20" strokeWidth="1.3" />)}
      {stops.map(([x, y], index) => (
        <g key={x} transform={`translate(${x} ${y}) rotate(${[-31, 16, -13][index]})`}
          stroke="#bebd98" strokeOpacity=".18" strokeWidth="1">
          {Array.from({length: 10}, (_, j) => {
            const t = j * 11 - 50;
            const e = Math.sqrt(Math.max(0, 1 - (t / 68) ** 2));
            return <g key={j}>
              <path d={`M${t} ${-69 * e} q-4 28 0 57 t5 ${55 * e}`} />
              <path d={`M${-90 * e} ${t} q36 4 74 0 t${72 * e} 3`} />
            </g>;
          })}
        </g>
      ))}
    </g>
    {[lake, bay].map((d) => <g key={d}>
      <path d={d} fill="url(#rail-map-water)" stroke="#89aaa0" strokeWidth="1.2" strokeOpacity=".55" />
      <path d={d} fill="url(#rail-map-ripples)" />
    </g>)}
    <g fontFamily={serif} fill="#adc4b9" opacity=".68" textAnchor="middle">
      <text x="415" y="81" fontSize="17" letterSpacing="6">太湖</text>
      <text x="810" y="424" fontSize="30" letterSpacing="14" transform="rotate(-7 810 424)">杭州湾</text>
    </g>
    <g opacity=".5" stroke="#d5d5b3">
      <path d="M26 25 H1114 V555 H26Z" strokeWidth=".65" fill="none"/>
      {Array.from({length: 54}, (_, i) => <path key={i} d={`M${40 + i * 20} 25 v${i % 5 ? 4 : 8} M${40 + i * 20} 555 v-${i % 5 ? 4 : 8}`} strokeWidth=".7"/>)}
    </g>
    <g transform="translate(1066 67)" fill="#f0ddac">
      <text textAnchor="middle" fontFamily={mono} fontSize="12" y="-9">N</text>
      <path d="M0 0L6 23 0 18Z" /><path d="M0 0L-6 23 0 18Z" opacity=".38" />
    </g>
  </>
));

export function RouteScene({stations = routeDefaults.stations, cues = routeDefaults.cues}: Partial<RouteSceneProps>) {
  const frame = useCurrentFrame();
  const move = ramp(frame, 0, 138);
  const fractions = tracks.map((_, i) => {
    const dwell = Math.min(10, Math.max(1, (cues[i + 1] - cues[i]) / 3));
    return ramp(frame, cues[i] + dwell, cues[i + 1]);
  });
  const segment = frame < cues[1] ? 0 : 1;
  const marker = trainPosition(segment, fractions[segment]);
  const rolling = Math.min(1, fractions[segment] * 17, (1 - fractions[segment]) * 17);
  const title = stations[0] === "杭州东" && stations[2] === "上海虹桥" ? "沪杭夜行" : "夜行线路";

  return (
    <AbsoluteFill style={{overflow: "hidden", background: "radial-gradient(ellipse at 20% 36%, #314a47, #182b2c 51%, #0d191e)", perspective: 1650, perspectiveOrigin: "38% 54%"}}>
      <div style={{
        position: "absolute", left: 67, top: 67, width: 1140, height: 580,
        transformOrigin: "50% 50%", overflow: "hidden", borderRadius: 15,
        border: "1px solid #7a8a70", backgroundColor: "#253f40",
        boxShadow: "3px 4px 0 #152e30, 7px 10px 0 #122527, 15px 30px 48px #071014b5",
        transform: `translateX(${9 - move * 13}px) rotateY(${15 - move * 10}deg) rotateX(${5 - move * 3}deg) rotateZ(${-2.6 + move * 1.5}deg)`,
      }}>
        <svg width="1140" height="580" viewBox="0 0 1140 580" role="img" aria-label={stations.join("，")}>
          <MapDrawing />
          <g transform="translate(60 76)">
            <text fontFamily={mono} fontSize="14" letterSpacing="3" fill="#dfca99">JIANGNAN / RAIL ATLAS</text>
            <text y="68" fontFamily={serif} fontSize="61" fontWeight="bold" letterSpacing="4" fill={ivory}>{title}</text>
            <path d="M2 90h48" stroke="#ea9371" strokeWidth="4" />
          </g>
          {lines.map((d, i) => {
            const brightness = i === 0 ? 1 - .62 * ramp(frame, cues[1] + 3, cues[1] + 18) : 1;
            return <g key={d} fill="none" strokeLinecap="round">
              <path d={d} stroke="#10282b" strokeWidth="9" />
              <path d={d} stroke="#a3b5a8" strokeWidth="2.5" strokeDasharray="4 8" opacity=".78" />
              {fractions[i] > 0 && <g opacity={brightness}>
                <path d={d} stroke="#f5a347" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - fractions[i]} strokeWidth="11" opacity=".17" />
                <path d={d} stroke={amber} pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - fractions[i]} strokeWidth="4" />
              </g>}
            </g>;
          })}
          {stations.map((name, i) => {
            const [x, y] = stops[i];
            const on = ramp(frame, cues[i] - 6, cues[i] + 2);
            const off = i < 2 ? ramp(frame, cues[i + 1] - 4, cues[i + 1] + 5) : 0;
            const focus = on * (1 - off);
            const pulse = clamp((frame - cues[i]) / 24);
            const below = i === 0;
            return <g key={i} transform={`translate(${x} ${y})`}>
              <circle r="93" fill="url(#rail-map-light)" opacity={focus} />
              <circle r={16 + 27 * pulse} stroke={amber} strokeWidth="1.7" fill="none" opacity={frame >= cues[i] ? (1 - pulse) * .86 : 0} />
              <circle r={8 + 3 * focus} fill="#213a3a" stroke="#c7d1ba" strokeWidth="2.5" />
              <circle r={5 + 2 * focus} fill={amber} opacity={on * (.4 + .6 * focus)} />
              <path d={below ? "M0 16v12" : "M0 -15v-12"} stroke={ivory} opacity=".56"/>
              <g transform={`translate(0 ${below ? 55 : -40})`} textAnchor="middle">
                <text y="0" fontFamily={sans} fontSize="27" fontWeight="600" letterSpacing="1.5" paintOrder="stroke" stroke="#263e3f" strokeWidth="6" strokeLinejoin="round" fill="#d2d9c8">{name}</text>
                <text y="0" fontFamily={sans} fontSize="27" fontWeight="600" letterSpacing="1.5" fill={ivory} opacity={focus}>{name}</text>
                <text y={below ? 22 : -34} fontFamily={sans} fontSize="14" fill="#f2ce8b" letterSpacing="3" opacity={.62 + .38 * focus}>
                  {["始发", "经停", "抵达"][i]}
                </text>
              </g>
            </g>;
          })}
          <g transform={`translate(${marker.point.join(" ")}) rotate(${marker.angle})`} opacity={rolling}>
            <ellipse rx="17" ry="9" fill={amber} opacity=".24" />
            <rect x="-11" y="-5" width="22" height="10" rx="5" fill="#fff0cd" stroke="#82533a" strokeWidth="1.6" />
            <path d="M-5 -1h6m3 0h2" stroke="#90603f" strokeWidth="2" strokeLinecap="round"/>
          </g>
          <g transform="translate(60 520)" fontFamily={sans} fontSize="14" fill="#d1d1b5">
            <path d="M0 -5h30" stroke={amber} strokeWidth="3" strokeLinecap="round" />
            <circle cx="15" cy="-5" r="4" fill="#294747" stroke={amber} strokeWidth="2" />
            <text x="43" letterSpacing="2">客运线路示意</text>
          </g>
        </svg>
      </div>
    </AbsoluteFill>
  );
}
