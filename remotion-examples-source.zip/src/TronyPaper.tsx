import React, {useLayoutEffect, useRef, useState} from 'react';
import {AbsoluteFill, cancelRender, continueRender, delayRender, Easing, interpolate, staticFile, useCurrentFrame} from 'remotion';

export type PaperInsertProps = {transparentBackground?: boolean};
const W = 1920;
const H = 1080;
const PAGE_H = 944;
const PAGE_W = PAGE_H * 593 / 716;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const progress = (f: number, a: number, b: number, easing = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {...clamp, easing});
type Vertex = {x: number; y: number; z: number; u: number; v: number};

/** A stroke in source-image coordinates. The text stays the original screenshot. */
function marker(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, t: number) {
  if (t <= 0) return;
  ctx.save();
  ctx.beginPath();
  ctx.rect(x - 3, y - 4, (width + 6) * t, 27);
  ctx.clip();
  ctx.globalCompositeOperation = 'multiply';
  ctx.fillStyle = 'rgba(255, 240, 0, .63)';
  ctx.beginPath();
  ctx.moveTo(x - 2, y + 1);
  ctx.bezierCurveTo(x + width * .3, y - 1, x + width * .7, y + 1, x + width, y - 1);
  ctx.lineTo(x + width + 1, y + 17);
  ctx.bezierCurveTo(x + width * .65, y + 19, x + width * .3, y + 17, x - 1, y + 19);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = 'rgba(255, 231, 0, .18)';
  ctx.fillRect(x, y + 13, width, 5);
  ctx.restore();
}

/** Texture mapping on a deformed, perspective-projected sheet. */
function triangle(ctx: CanvasRenderingContext2D, texture: HTMLCanvasElement, a: Vertex, b: Vertex, c: Vertex) {
  const ax = a.u * texture.width, ay = a.v * texture.height;
  const bx = b.u * texture.width, by = b.v * texture.height;
  const cx = c.u * texture.width, cy = c.v * texture.height;
  const det = ax * (by - cy) + bx * (cy - ay) + cx * (ay - by);
  if (Math.abs(det) < .00001) return;
  const m11 = (a.x * (by - cy) + b.x * (cy - ay) + c.x * (ay - by)) / det;
  const m21 = (a.y * (by - cy) + b.y * (cy - ay) + c.y * (ay - by)) / det;
  const m12 = (a.x * (cx - bx) + b.x * (ax - cx) + c.x * (bx - ax)) / det;
  const m22 = (a.y * (cx - bx) + b.y * (ax - cx) + c.y * (bx - ax)) / det;
  const dx = a.x - m11 * ax - m12 * ay;
  const dy = a.y - m21 * ax - m22 * ay;
  // Slight overlap suppresses antialias cracks between adjacent triangles.
  const mx = (a.x + b.x + c.x) / 3, my = (a.y + b.y + c.y) / 3;
  const expand = (p: Vertex) => {
    const d = Math.hypot(p.x - mx, p.y - my);
    return {x: p.x + (p.x - mx) * .42 / d, y: p.y + (p.y - my) * .42 / d};
  };
  const aa = expand(a), bb = expand(b), cc = expand(c);
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(aa.x, aa.y); ctx.lineTo(bb.x, bb.y); ctx.lineTo(cc.x, cc.y); ctx.closePath();
  ctx.clip();
  ctx.transform(m11, m21, m12, m22, dx, dy);
  ctx.drawImage(texture, 0, 0);
  ctx.restore();
}

function paint(canvas: HTMLCanvasElement, image: HTMLImageElement, f: number, alpha: boolean) {
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, W, H);
  if (!alpha) {
    const bg = ctx.createRadialGradient(960, 470, 40, 960, 540, 1200);
    bg.addColorStop(0, '#32383c'); bg.addColorStop(1, '#14191e');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
  }
  if (f < 15) return;

  const flight = progress(f, 15, 53, Easing.bezier(.12, .48, .22, 1));
  const open = progress(f, 29, 95, Easing.bezier(.25, .05, .23, 1));
  const corners = 1 - progress(f, 65, 119, Easing.bezier(.24, 0, .3, 1));
  const texture = document.createElement('canvas');
  texture.width = image.naturalWidth; texture.height = image.naturalHeight;
  const tc = texture.getContext('2d')!;
  tc.drawImage(image, 0, 0);
  marker(tc, 151, 117, 85, progress(f, 132, 150, Easing.bezier(.18, .2, .35, 1)));
  marker(tc, 282, 117, 72, progress(f, 164, 183, Easing.bezier(.18, .2, .35, 1)));
  // Bake continuous light into the texture so no triangle gets a separate dark edge.
  const lighting = tc.createLinearGradient(0, 0, texture.width, 0);
  for (let i = 0; i <= 16; i++) {
    const opacity = (1 - open) * (.04 + .22 * (1 + Math.sin(i / 16 * Math.PI * 2 - .8)) / 2);
    lighting.addColorStop(i / 16, `rgba(42,46,58,${opacity})`);
  }
  tc.fillStyle = lighting; tc.fillRect(0, 0, texture.width, texture.height);
  for (const [cx, cy] of [[texture.width, 0], [0, texture.height]]) {
    const light = tc.createRadialGradient(cx, cy, 0, cx, cy, 100);
    light.addColorStop(0, `rgba(44,48,54,${.16 * corners})`);
    light.addColorStop(1, 'rgba(44,48,54,0)');
    tc.fillStyle = light; tc.fillRect(0, 0, texture.width, texture.height);
  }

  const yaw = (-76 * (1 - open)) * Math.PI / 180;
  const roll = (-12 * (1 - flight) + 2.4 * (1 - open)) * Math.PI / 180;
  const pitch = (9 * (1 - open)) * Math.PI / 180;
  const bend = 3.5 * (1 - open);
  const scale = (.81 + .19 * flight) * (.86 + .14 * open);
  const centerX = 960 + 1360 * (1 - flight);
  const centerY = 540 - 190 * (1 - flight);

  const vertex = (u: number, v: number): Vertex => {
    const theta = (u - .5) * bend;
    let x = bend > .0001 ? PAGE_W * Math.sin(theta) / bend : PAGE_W * (u - .5);
    let y = PAGE_H * (v - .5);
    let z = bend > .0001 ? PAGE_W * (1 - Math.cos(theta)) / bend : 0;
    // Diagonal torsion and two lifted corners affect silhouette and print together.
    z += 112 * (1 - open) * Math.sin((v - .5) * Math.PI) * (u - .5);
    const tr = Math.exp(-((1 - u) ** 2 / .014 + v ** 2 / .018));
    const bl = Math.exp(-(u ** 2 / .018 + (1 - v) ** 2 / .016));
    z += corners * (64 * tr + 78 * bl);
    x += corners * (-21 * tr + 23 * bl);
    y += corners * (24 * tr - 28 * bl);
    const xx = x * Math.cos(yaw) + z * Math.sin(yaw);
    const zz = -x * Math.sin(yaw) + z * Math.cos(yaw);
    const yy = y * Math.cos(pitch) - zz * Math.sin(pitch);
    z = y * Math.sin(pitch) + zz * Math.cos(pitch);
    x = xx * Math.cos(roll) - yy * Math.sin(roll);
    y = xx * Math.sin(roll) + yy * Math.cos(roll);
    const perspective = 1850 / (1850 - z);
    return {x: centerX + x * perspective * scale, y: centerY + y * perspective * scale, z, u, v};
  };
  const nx = 32, ny = 40;
  const grid = Array.from({length: ny + 1}, (_, j) => Array.from({length: nx + 1}, (_, i) => vertex(i / nx, j / ny)));
  const perimeter = [
    ...grid[0], ...grid.slice(1).map(row => row[nx]),
    ...grid[ny].slice(0, nx).reverse(), ...grid.slice(1, ny).reverse().map(row => row[0]),
  ];
  const outline = () => {
    ctx.beginPath(); perimeter.forEach((v, i) => i === 0 ? ctx.moveTo(v.x, v.y) : ctx.lineTo(v.x, v.y)); ctx.closePath();
  };
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,.38)';
  ctx.shadowBlur = 25 + 20 * (1 - open); ctx.shadowOffsetX = -13; ctx.shadowOffsetY = 23;
  ctx.fillStyle = '#fff'; outline(); ctx.fill();
  ctx.restore();

  // Draw the image once at rest for perfectly sharp type and no mesh seams.
  if (f >= 119) {
    ctx.drawImage(texture, 960 - PAGE_W / 2, 540 - PAGE_H / 2, PAGE_W, PAGE_H);
    return;
  }
  const faces: {a: Vertex; b: Vertex; c: Vertex; depth: number}[] = [];
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    const a = grid[j][i], b = grid[j][i + 1], c = grid[j + 1][i + 1], d = grid[j + 1][i];
    faces.push({a, b, c, depth: (a.z + b.z + c.z) / 3}, {a, b: c, c: d, depth: (a.z + c.z + d.z) / 3});
  }
  faces.sort((a, b) => a.depth - b.depth);
  for (const face of faces) triangle(ctx, texture, face.a, face.b, face.c);
}

export const PaperInsert: React.FC<PaperInsertProps> = ({transparentBackground = false}) => {
  const frame = useCurrentFrame();
  const canvas = useRef<HTMLCanvasElement>(null);
  const [source, setSource] = useState<HTMLImageElement | null>(null);
  const [handle] = useState(() => delayRender('Loading original Trony screenshot'));
  useLayoutEffect(() => {
    const image = new Image();
    image.onload = () => setSource(image);
    image.onerror = () => cancelRender(new Error('Unable to load paper/trony-post.png'));
    image.src = staticFile('paper/trony-post.png');
    return () => {image.onload = null; image.onerror = null;};
  }, []);
  useLayoutEffect(() => {
    if (!canvas.current || !source) return;
    paint(canvas.current, source, frame, transparentBackground);
    continueRender(handle);
  }, [frame, source, handle, transparentBackground]);
  return <AbsoluteFill><canvas ref={canvas} width={W} height={H} style={{width: '100%', height: '100%'}}/></AbsoluteFill>;
};
