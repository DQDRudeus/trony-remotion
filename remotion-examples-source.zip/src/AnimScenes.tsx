import React from 'react';
import {AbsoluteFill, Img, OffthreadVideo, Series, staticFile, useCurrentFrame} from 'remotion';
import {ArtTitle, Card, ChalkBoard, dimStyle, ease, FlowChain, MediaInside, ScrollSheet, soft, theme, Vignette} from './AnimKit';

/* ─────────────── 01 背后的视频在动，前面两个字慢慢浮现 ─────────────── */

export const AnimTitleScene: React.FC = () => {
  const frame = useCurrentFrame();
  const veil = ease(frame, 0, 30);
  return (
    <AbsoluteFill style={{overflow: 'hidden', backgroundColor: '#08100F'}}>
      {/* 底层动态素材：不推不摇，只保留画面自身的运动 */}
      <OffthreadVideo
        muted
        src={staticFile('media/rail-station.mp4')}
        style={{width: '100%', height: '100%', objectFit: 'cover', display: 'block'}}
      />
      <AbsoluteFill style={{background: 'linear-gradient(100deg, rgba(4,14,16,.90) 0%, rgba(5,16,18,.55) 46%, rgba(6,18,20,.18) 100%)', opacity: veil}} />
      <AbsoluteFill style={{background: 'linear-gradient(0deg, rgba(3,10,12,.72) 0%, transparent 42%)', opacity: veil}} />
      <Vignette strength={0.6} />

      <div style={{position: 'absolute', left: 118, top: 210}}>
        <ArtTitle
          text="夜行"
          kicker="JIANGNAN / NIGHT RAIL"
          sub="杭州东 — 嘉兴南 — 上海虹桥"
          start={16}
          size={182}
          stagger={10}
        />
      </div>

      {/* 右下角的小注：像字幕条一样渐显，不抢主体 */}
      <div
        style={{
          position: 'absolute',
          right: 96,
          bottom: 84,
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          opacity: ease(frame, 66, 92),
          transform: `translateY(${(1 - ease(frame, 66, 92)) * 10}px)`,
        }}
      >
        <div style={{width: 30, height: 1, background: 'rgba(255,244,223,.5)'}} />
        <div style={{font: '12px ' + theme.mono, letterSpacing: 3, color: 'rgba(255,244,223,.7)'}}>背景画面持续运动 · 字层独立浮现</div>
      </div>

      {/* 底部一束暖光，把字和暗部压在一起 */}
      <div
        aria-hidden
        style={{
          position: 'absolute',
          left: '-10%',
          bottom: '-18%',
          width: '70%',
          height: '52%',
          background: 'radial-gradient(closest-side, rgba(232,163,61,.20), transparent)',
          filter: 'blur(28px)',
          opacity: veil,
        }}
      />
    </AbsoluteFill>
  );
};

/* ─────────────── 02 流程图：线索一段一段画出来，点名就亮 ─────────────── */

export const AnimFlowScene: React.FC = () => (
  <AbsoluteFill>
    <FlowChain
      heading="客流为什么会突然挤上来"
      steps={[
        {kicker: 'STEP 01', title: '需求堆叠', note: '周末 + 节假日 + 返程，三个波峰撞在一起'},
        {kicker: 'STEP 02', title: '运力见顶', note: '车底数量是固定的，加开也有限'},
        {kicker: 'STEP 03', title: '调度换解', note: '不靠加车，靠把座位卖给最该买的人'},
      ]}
      cues={[14, 58, 102]}
      conclusion="结论：问题不在车不够，在席位没有按需求分。"
      start={8}
    />
  </AbsoluteFill>
);

/* ─────────────── 03 卡片：内嵌动态视频 + 点名提亮 + 圆角阴影 ─────────────── */

const focusAt = (frame: number, cues: number[], i: number) => {
  const inn = soft(frame, cues[i], cues[i] + 16);
  const next = i + 1 < cues.length ? cues[i + 1] : Number.POSITIVE_INFINITY;
  const out = Number.isFinite(next) ? soft(frame, next, next + 16) : 0;
  return inn * (1 - out);
};

export const AnimMediaScene: React.FC = () => {
  const frame = useCurrentFrame();
  const cues = [10, 58, 104];
  const f0 = focusAt(frame, cues, 0);
  const f1 = focusAt(frame, cues, 1);
  const f2 = focusAt(frame, cues, 2);
  const headIn = ease(frame, 0, 22);

  return (
    <AbsoluteFill style={{overflow: 'hidden', backgroundColor: '#0A1214', fontFamily: theme.sans}}>
      <div aria-hidden style={{position: 'absolute', inset: 0, background: 'radial-gradient(900px 640px at 24% 12%, #223B3A 0%, #132527 48%, #081214 100%)'}} />

      <div style={{position: 'absolute', left: 84, top: 54, opacity: headIn, transform: `translateY(${(1 - headIn) * -10}px)`}}>
        <div style={{font: '12px ' + theme.mono, letterSpacing: 4, color: '#E6BE84'}}>CARD STACK / 卡片轮换</div>
        <div style={{fontFamily: theme.serif, fontSize: 34, fontWeight: 700, color: theme.cream, marginTop: 8, letterSpacing: 1}}>
          讲到哪一张，哪一张就亮
        </div>
      </div>

      {/* 主卡：内嵌动态视频 */}
      <div style={{position: 'absolute', inset: 0}}>
        <Card focus={f0} style={{left: 84, top: 132, width: 566, height: 344}}>
          <div style={{position: 'absolute', inset: 0, opacity: 0.40 + 0.60 * f0, filter: `saturate(${0.35 + 0.65 * f0})`}}>
            <MediaInside src="media/rail-window.mp4" />
          </div>
          <div style={{position: 'absolute', left: 26, bottom: 22, right: 26, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between'}}>
            <div>
              <div style={{font: '11px ' + theme.mono, letterSpacing: 3, color: 'rgba(255,240,210,.82)'}}>B-ROLL / LIVE</div>
              <div style={{fontFamily: theme.serif, fontSize: 32, fontWeight: 700, color: '#FFF4DF', letterSpacing: 2, textShadow: '0 3px 14px rgba(0,0,0,.55)'}}>
                窗口里的夜行
              </div>
            </div>
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: 999,
                border: '1px solid rgba(255,240,210,.55)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#FFF4DF',
                fontSize: 14,
              }}
            >
              播
            </div>
          </div>
        </Card>
      </div>

      {/* 副卡 A：照片，带纸张边框 */}
      <div style={{position: 'absolute', inset: 0}}>
        <Card tone="paper" focus={f1} style={{left: 686, top: 132, width: 514, height: 196}}>
          <div style={{position: 'absolute', inset: 0, opacity: 0.35 + 0.65 * f1, filter: `saturate(${0.4 + 0.6 * f1})`}}>
            <Img src={staticFile('media/reaction.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
          </div>
          <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(8,16,16,.86) 0%, rgba(8,16,16,.30) 58%, transparent 100%)'}} />
          <div style={{position: 'absolute', left: 24, top: 34, width: 220}}>
            <div style={{font: '11px ' + theme.mono, letterSpacing: 3, color: '#EAC58A'}}>REFERENCE</div>
            <div style={{fontFamily: theme.serif, fontSize: 27, fontWeight: 700, color: '#FFF4DF', marginTop: 6, lineHeight: 1.25}}>
              这个表情，正好能用
            </div>
          </div>
        </Card>
      </div>

      {/* 副卡 B：数据卡，渐变交融 */}
      <div style={{position: 'absolute', inset: 0}}>
        <Card focus={f2} style={{left: 686, top: 360, width: 514, height: 216}}>
            <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(135deg,#F8F0E1 0%,#EFE3CD 52%,#E1D2B8 100%)'}} />
            <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(120% 80% at 100% 0%, rgba(232,163,61,.20), transparent 58%)', opacity: 0.4 + 0.6 * f2}} />
            <div style={{position: 'absolute', left: 26, top: 24, right: 26}}>
              <div style={{font: '11px ' + theme.mono, letterSpacing: 3, color: '#9A7A48'}}>SEAT / LOAD</div>
              <div style={{display: 'flex', alignItems: 'flex-end', gap: 10, marginTop: 6}}>
                <span style={{fontFamily: theme.serif, fontSize: 56, fontWeight: 700, color: theme.ink, lineHeight: 1}}>
                  {(78 * soft(frame, cues[2], cues[2] + 26)).toFixed(0)}
                </span>
                <span style={{fontFamily: theme.serif, fontSize: 22, color: '#9A7A48', paddingBottom: 6}}>% 上座</span>
              </div>
              <div style={{marginTop: 14, height: 10, borderRadius: 5, background: 'rgba(20,22,26,.12)', overflow: 'hidden'}}>
                <div
                  style={{
                    width: `${78 * soft(frame, cues[2], cues[2] + 26)}%`,
                    height: '100%',
                    borderRadius: 5,
                    background: `linear-gradient(90deg,${theme.accent},${theme.accentDeep})`,
                  }}
                />
              </div>
              <div style={{marginTop: 12, fontSize: 14, color: '#6B6154', letterSpacing: 1}}>同一趟车，席位卖给了更需要的人</div>
            </div>
        </Card>
      </div>
      <Vignette strength={0.5} />
    </AbsoluteFill>
  );
};

/* ─────────────── 04 侧视黑板：粉笔一行一行写上去 ─────────────── */

export const AnimBoardScene: React.FC = () => (
  <AbsoluteFill>
    <ChalkBoard
      heading="为什么会这样"
      rows={[
        {text: '一、需求是堆叠的', cue: 18, note: '周末 · 假期 · 返程'},
        {text: '二、运力是固定的', cue: 58, note: '车底有限'},
        {text: '三、解法在分配上', cue: 100, note: '把席位卖对'},
      ]}
      footer="选择一变，结果就变。"
    />
  </AbsoluteFill>
);

/* ─────────────── 05 卷纸：卷着进来，展开后逐句划亮 ─────────────── */

export const AnimScrollScene: React.FC = () => (
  <AbsoluteFill>
    <ScrollSheet
      title="随车手记"
      eyebrow="杭州东　经嘉兴南　至上海虹桥"
      lines={[
        {before: '离开杭州，', keyword: '站台灯', after: '在车窗里拉长。', cue: 62},
        {before: '驶过嘉兴，', keyword: '河面', after: '映出一排暖灯。', cue: 94},
        {before: '临近上海，', keyword: '楼群', after: '从夜色里浮出来。', cue: 124},
      ]}
    />
  </AbsoluteFill>
);

export const animLengths = {title: 132, flow: 160, media: 144, board: 144, scroll: 168};
export const animTotal = animLengths.title + animLengths.flow + animLengths.media + animLengths.board + animLengths.scroll;

/** 把五个纯动画段落按顺序集成，方便一眼看全 */
export const XiaolinAnimPack: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#08100F'}}>
    <Series>
      <Series.Sequence durationInFrames={animLengths.title} name="01 艺术字浮现">
        <AnimTitleScene />
      </Series.Sequence>
      <Series.Sequence durationInFrames={animLengths.flow} name="02 流程线索点名">
        <AnimFlowScene />
      </Series.Sequence>
      <Series.Sequence durationInFrames={animLengths.media} name="03 卡片轮换">
        <AnimMediaScene />
      </Series.Sequence>
      <Series.Sequence durationInFrames={animLengths.board} name="04 黑板书写">
        <AnimBoardScene />
      </Series.Sequence>
      <Series.Sequence durationInFrames={animLengths.scroll} name="05 卷纸展开">
        <AnimScrollScene />
      </Series.Sequence>
    </Series>
  </AbsoluteFill>
);
