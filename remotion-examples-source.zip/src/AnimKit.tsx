import React from 'react';
import {AbsoluteFill, Easing, Img, OffthreadVideo, interpolate, staticFile, useCurrentFrame} from 'remotion';

/* ───────────────────────── 统一的设计令牌 ───────────────────────── */

export const theme = {
  ink: '#14161A',
  deep: '#0C1214',
  panel: '#101A1C',
  paper: '#F6EEE0',
  paperMid: '#EBDCC2',
  paperDeep: '#DFCFB2',
  accent: '#E8A33D',
  accentDeep: '#C4562F',
  cream: '#FFF4DF',
  chalk: '#F3EADA',
  serif: '"Noto Serif SC", "STSong", "SimSun", serif',
  sans: '"Microsoft YaHei", "Noto Sans SC", sans-serif',
  mono: '"Consolas", "Courier New", monospace',
  /** 所有卡片共用一套投影：近处实、远处软 */
  cardShadow: '0 30px 72px rgba(3,10,12,.52), 0 9px 22px rgba(3,10,12,.30), 0 0 0 1px rgba(255,247,229,.14) inset',
  glow: (k: number) => `0 0 0 ${2 + 2 * k}px rgba(232,163,61,${0.30 + 0.34 * k}), 0 0 ${46 * k}px rgba(232,163,61,${0.34 * k})`,
  rad: {card: 30, tile: 22, chip: 14},
};

export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

type Curve = (t: number) => number;
export const travel: Curve = Easing.bezier(0.24, 0.72, 0.24, 1);
export const settle: Curve = Easing.bezier(0.16, 0.84, 0.24, 1);

export const ease = (frame: number, from: number, to: number, curve: Curve = travel) =>
  interpolate(frame, [from, to], [0, 1], {...clamp, easing: curve});

export const soft = (frame: number, from: number, to: number) => {
  const t = interpolate(frame, [from, to], [0, 1], clamp);
  return t * t * (3 - 2 * t);
};

/** 提亮当前那一块，其余压暗——小Lin 最常用的“点名”动作 */
export const dimStyle = (focus: number): React.CSSProperties => ({
  opacity: 0.40 + 0.60 * focus,
  filter: `saturate(${0.3 + 0.7 * focus}) brightness(${0.84 + 0.16 * focus})`,
  transform: `scale(${0.975 + 0.025 * focus})`,
});

/* ───────────────────────── 01 艺术字：一个字一个字浮现 ───────────────────────── */

export type ArtTitleProps = {
  text: string;
  sub?: string;
  kicker?: string;
  start?: number;
  size?: number;
  stagger?: number;
  color?: string;
  glowColor?: string;
  /** 字后面是否带一条逐渐画出的细线 */
  rule?: boolean;
  style?: React.CSSProperties;
};

export const ArtTitle: React.FC<ArtTitleProps> = ({
  text,
  sub,
  kicker,
  start = 0,
  size = 156,
  stagger = 7,
  color = theme.cream,
  glowColor = 'rgba(232,163,61,.42)',
  rule = true,
  style,
}) => {
  const frame = useCurrentFrame();
  const chars = Array.from(text);
  const span = start + Math.max(1, chars.length - 1) * stagger;
  const plate = ease(frame, start - 8, span + 30);
  const ruleW = ease(frame, span + 12, span + 44);
  const subIn = ease(frame, span + 8, span + 34);

  return (
    <div style={{position: 'relative', display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', ...style}}>
      {/* 字后面的暖光板，让字从画面里“浮”出来 */}
      <div
        aria-hidden
        style={{
          position: 'absolute',
          left: '-18%',
          right: '-14%',
          top: '-26%',
          bottom: '-10%',
          background: `radial-gradient(58% 64% at 42% 60%, ${glowColor}, transparent 72%)`,
          opacity: plate * 0.92,
          filter: 'blur(20px)',
          pointerEvents: 'none',
        }}
      />
      {kicker && (
        <div
          style={{
            position: 'relative',
            marginBottom: 14,
            font: '13px ' + theme.mono,
            letterSpacing: 5,
            color: '#EAC58A',
            opacity: ease(frame, start - 6, start + 12),
            display: 'flex',
            alignItems: 'center',
            gap: 12,
          }}
        >
          <span style={{width: 34, height: 2, background: theme.accent, display: 'inline-block'}} />
          {kicker}
        </div>
      )}
      <div style={{position: 'relative', display: 'flex', alignItems: 'flex-end', flexWrap: 'nowrap'}}>
        {chars.map((char, i) => {
          const t = soft(frame, start + i * stagger, start + i * stagger + 20);
          const edge = -24 + t * 150;
          const mask = `linear-gradient(101deg, #000 ${edge - 18}%, rgba(0,0,0,.92) ${edge}%, transparent ${edge + 5}%)`;
          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                fontFamily: theme.serif,
                fontWeight: 700,
                fontSize: size,
                lineHeight: 1.04,
                letterSpacing: `${0.01 + (1 - t) * 0.09}em`,
                paddingRight: `${0.03 + (1 - t) * 0.07}em`,
                color,
                opacity: Math.min(1, t * 1.3),
                transform: `translateY(${(1 - t) * 26}px) scale(${1.09 - 0.09 * t})`,
                filter: `blur(${(1 - t) * 10}px)`,
                textShadow: `0 ${Math.round(18 - 18 * t)}px ${Math.round(34 - 16 * t)}px rgba(0,0,0,.44)`,
                maskImage: mask,
                WebkitMaskImage: mask,
              }}
            >
              {char}
            </span>
          );
        })}
      </div>
      {rule && (
        <div
          style={{
            position: 'relative',
            marginTop: 10,
            height: 3,
            width: 44 + ruleW * (chars.length * size * 0.34),
            background: `linear-gradient(90deg, ${theme.accent}, ${theme.accentDeep})`,
            borderRadius: 2,
            opacity: 0.9,
          }}
        />
      )}
      {sub && (
        <div
          style={{
            position: 'relative',
            marginTop: 14,
            fontFamily: theme.sans,
            fontSize: 20,
            letterSpacing: 4,
            color: 'rgba(255,244,223,.92)',
            opacity: subIn,
            transform: `translateY(${(1 - subIn) * 10}px)`,
          }}
        >
          {sub}
        </div>
      )}
    </div>
  );
};

/* ───────────────────────── 02 卡片底座：圆角 + 阴影 + 渐变交融 ───────────────────────── */

export type CardProps = React.PropsWithChildren<{
  focus?: number;
  tone?: 'paper' | 'deep';
  style?: React.CSSProperties;
  inner?: React.CSSProperties;
}>;

export const Card: React.FC<CardProps> = ({focus = 0, tone = 'paper', style, inner, children}) => {
  const paper = tone === 'paper';
  return (
    <div
      style={{
        position: 'absolute',
        padding: 5,
        boxSizing: 'border-box',
        borderRadius: theme.rad.card,
        background: paper
          ? 'linear-gradient(135deg,#F7E8CB 0%,#E9D7B4 28%,#AEBAA6 62%,#7A968F 100%)'
          : 'linear-gradient(135deg,#2B4142 0%,#1A2C2E 52%,#122224 100%)',
        boxShadow: `${theme.glow(focus)}, ${theme.cardShadow}`,
        overflow: 'hidden',
        ...style,
      }}
    >
      {/* 卡片自身的流动高光 */}
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: 'inherit',
          background: paper
            ? 'radial-gradient(130% 90% at 6% 0%, rgba(255,253,245,.62), transparent 56%)'
            : 'radial-gradient(120% 90% at 88% 0%, rgba(232,163,61,.16), transparent 62%)',
          pointerEvents: 'none',
        }}
      />
      <div
        style={{
          position: 'relative',
          height: '100%',
          width: '100%',
          borderRadius: theme.rad.card - 5,
          overflow: 'hidden',
          background: paper
            ? 'linear-gradient(140deg,#F8F0E1 0%,#EFE3CD 52%,#E1D2B8 100%)'
            : 'linear-gradient(140deg,#132022 0%,#0D181A 60%,#0A1315 100%)',
          ...inner,
        }}
      >
        {children}
        {/* 没被点名的卡片：整体压暗（不是变透明），避免透出背景 */}
        <div
          aria-hidden
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: 'inherit',
            background: 'linear-gradient(160deg, rgba(6,14,16,.88), rgba(6,14,16,.60))',
            opacity: (1 - focus) * 0.50,
            pointerEvents: 'none',
          }}
        />
      </div>
    </div>
  );
};

/** 卡片里嵌的动态视频：边缘用渐变压进卡片，不会出现生硬方角 */
export const MediaInside: React.FC<{src: string; overlay?: string; style?: React.CSSProperties}> = ({
  src,
  overlay = 'linear-gradient(200deg, rgba(8,14,16,.42), transparent 46%, rgba(232,163,61,.16) 100%)',
  style,
}) => (
  <div style={{position: 'absolute', inset: 0, overflow: 'hidden', borderRadius: 'inherit'}}>
    <OffthreadVideo
      muted
      src={staticFile(src)}
      style={{width: '100%', height: '100%', objectFit: 'cover', display: 'block', ...style}}
    />
    <div aria-hidden style={{position: 'absolute', inset: 0, background: overlay, pointerEvents: 'none'}} />
    <div
      aria-hidden
      style={{
        position: 'absolute',
        inset: 0,
        boxShadow: 'inset 0 0 60px rgba(4,12,14,.62), inset 0 0 0 1px rgba(255,246,226,.16)',
        borderRadius: 'inherit',
        pointerEvents: 'none',
      }}
    />
  </div>
);

/* ───────────────────────── 03 手绘流程链：线索逐段画出 + 点名高亮 ───────────────────────── */

export type FlowStep = {kicker: string; title: string; note: string};

export const FlowChain: React.FC<{
  steps: FlowStep[];
  cues: number[];
  heading?: string;
  conclusion?: string;
  start?: number;
}> = ({steps, cues, heading, conclusion, start = 10}) => {
  const frame = useCurrentFrame();
  const nodeW = 252;
  const nodeH = 152;
  const gap = 54;
  const totalW = steps.length * nodeW + (steps.length - 1) * gap;
  const left0 = (1280 - totalW) / 2;
  const top0 = 316;
  const focus = steps.map((_s, i) => {
    const inn = soft(frame, cues[i], cues[i] + 16);
    const next = i + 1 < steps.length ? cues[i + 1] : Number.POSITIVE_INFINITY;
    const out = Number.isFinite(next) ? soft(frame, next, next + 16) : 0;
    return inn * (1 - out);
  });
  const anyFocus = Math.max(...focus, 0);
  const line = (i: number) => soft(frame, cues[i] + 12, cues[i] + 36);
  const tailIn = ease(frame, cues[steps.length - 1] + 26, cues[steps.length - 1] + 52);
  const headIn = ease(frame, start, start + 22);

  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(900px 620px at 22% 14%, #24403F 0%, #16292B 46%, #0B1517 100%), linear-gradient(150deg, rgba(232,163,61,.06), transparent 52%)',
        }}
      />
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0.16,
          backgroundImage:
            'linear-gradient(rgba(230,240,225,.16) 1px, transparent 1px), linear-gradient(90deg, rgba(230,240,225,.16) 1px, transparent 1px)',
          backgroundSize: '76px 76px',
        }}
      />

      {/* 标题：从左边一条细线拉出来 */}
      <div style={{position: 'absolute', left: 110, top: 138, opacity: headIn, transform: `translateX(${(1 - headIn) * -18}px)`}}>
        <div style={{font: '12px ' + theme.mono, letterSpacing: 5, color: '#E6BE84'}}>LOGIC / 线索</div>
        <div style={{display: 'flex', alignItems: 'center', gap: 16, marginTop: 8}}>
          <span style={{width: 6, height: 44, borderRadius: 3, background: `linear-gradient(180deg,${theme.accent},${theme.accentDeep})`}} />
          <span style={{fontFamily: theme.serif, fontSize: 46, fontWeight: 700, color: theme.cream, letterSpacing: 2}}>
            {heading ?? '线索是怎么串起来的'}
          </span>
        </div>
      </div>

      {/* 连接线 */}
      <svg width={1280} height={720} style={{position: 'absolute', inset: 0}} aria-hidden>
        {steps.slice(0, -1).map((_s, i) => {
          const from = left0 + i * (nodeW + gap) + nodeW;
          const to = left0 + (i + 1) * (nodeW + gap);
          const y = top0 + nodeH / 2;
          const p = line(i);
          const d = `M${from} ${y} C${from + 20} ${y - 44} ${to - 20} ${y - 44} ${to} ${y}`;
          return (
            <g key={i}>
              <path d={d} fill="none" stroke="#0A1416" strokeWidth={9} opacity={0.5 * p} />
              <path
                d={d}
                fill="none"
                stroke={theme.accent}
                strokeWidth={3.4}
                strokeLinecap="round"
                pathLength={1}
                strokeDasharray="1 1"
                strokeDashoffset={1 - p}
                opacity={0.9}
              />
              <g opacity={p} transform={`translate(${to} ${y})`}>
                <polygon points="0,0 -13,-7 -13,7" fill={theme.accent} />
              </g>
              {/* 沿线跑的小光点 */}
              {p > 0.2 && p < 0.98 && (
                <circle
                  cx={from + (to - from) * p}
                  cy={y - 44 * Math.sin(Math.PI * Math.min(1, Math.max(0, p)) * 0.9)}
                  r={4.5}
                  fill="#FFE6BC"
                  opacity={0.85}
                />
              )}
            </g>
          );
        })}
        {/* 末端箭头强调 */}
        <g opacity={tailIn}>
          <path
            d={`M${left0 + (steps.length - 1) * (nodeW + gap) + nodeW + 6} ${top0 + nodeH / 2} h${18 + 14 * tailIn}`}
            stroke={theme.accent}
            strokeWidth={3}
            strokeLinecap="round"
          />
        </g>
      </svg>

      {/* 节点 */}
      {steps.map((s, i) => {
        const inT = soft(frame, start + 6 + i * 8, start + 30 + i * 8);
        const f = focus[i];
        const dimOthers = 0.36 * anyFocus * (1 - f);
        return (
          <div
            key={s.title}
            style={{
              position: 'absolute',
              left: left0 + i * (nodeW + gap),
              top: top0,
              width: nodeW,
              height: nodeH,
              borderRadius: theme.rad.card,
              padding: 5,
              boxSizing: 'border-box',
              background: `linear-gradient(135deg, rgba(247,232,203,${0.92}) 0%, rgba(233,215,180,.88) 30%, rgba(168,183,164,.8) 70%, rgba(120,150,143,.78) 100%)`,
              boxShadow: `${theme.glow(f)}, 0 26px 54px rgba(3,12,14,.5), 0 4px 12px rgba(3,12,14,.28)`,
              opacity: inT * (1 - dimOthers),
              transform: `translateY(${(1 - inT) * 26 + f * -6}px) scale(${0.96 + 0.04 * inT + 0.03 * f})`,
            }}
          >
            <div
              style={{
                position: 'relative',
                height: '100%',
                borderRadius: theme.rad.card - 5,
                overflow: 'hidden',
                padding: '18px 20px',
                boxSizing: 'border-box',
                background: 'linear-gradient(145deg,#FAF2E3 0%,#F1E6CE 58%,#E5D6BB 100%)',
              }}
            >
              {/* 左缘强调条：点名时亮起 */}
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  top: 0,
                  bottom: 0,
                  width: 5,
                  background: `linear-gradient(180deg,${theme.accent},${theme.accentDeep})`,
                  opacity: 0.22 + 0.78 * f,
                }}
              />
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                <span style={{font: '11px ' + theme.mono, letterSpacing: 2.5, color: '#9A7A48'}}>{s.kicker}</span>
                <span
                  style={{
                    fontFamily: theme.serif,
                    fontSize: 13,
                    color: '#8A7452',
                    width: 22,
                    height: 22,
                    borderRadius: 999,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'rgba(20,22,26,.06)',
                  }}
                >
                  {i + 1}
                </span>
              </div>
              <div style={{marginTop: 8, fontFamily: theme.serif, fontSize: 34, fontWeight: 700, color: theme.ink, letterSpacing: 2}}>
                {s.title}
              </div>
              <div style={{marginTop: 6, fontFamily: theme.sans, fontSize: 15, lineHeight: 1.5, color: '#6B6154'}}>{s.note}</div>
            </div>
          </div>
        );
      })}

      {/* 结论条：最后一步讲完才出现 */}
      {conclusion && (
        <div
          style={{
            position: 'absolute',
            left: 110,
            right: 110,
            top: top0 + nodeH + 92,
            display: 'flex',
            alignItems: 'center',
            gap: 16,
            opacity: tailIn,
            transform: `translateY(${(1 - tailIn) * 14}px)`,
          }}
        >
          <div style={{width: 4, height: 40, borderRadius: 2, background: `linear-gradient(180deg,${theme.accent},${theme.accentDeep})`}} />
          <div style={{fontFamily: theme.serif, fontSize: 27, color: theme.cream, letterSpacing: 1.5}}>{conclusion}</div>
        </div>
      )}
    </AbsoluteFill>
  );
};

/* ───────────────────────── 04 侧视黑板：粉笔逐行写上去 ───────────────────────── */

export const ChalkBoard: React.FC<{
  heading: string;
  rows: {text: string; cue: number; note?: string}[];
  footer?: string;
}> = ({heading, rows, footer}) => {
  const frame = useCurrentFrame();
  const boardIn = ease(frame, 0, 26, settle);
  const active = rows.reduce((acc, r, i) => (frame >= r.cue ? i : acc), -1);

  return (
    <AbsoluteFill style={{backgroundColor: '#0A1012', overflow: 'hidden', fontFamily: theme.sans}}>
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(1000px 660px at 26% 16%, #1E2E2B 0%, #101B1D 48%, #070C0E 100%)',
        }}
      />
      <div style={{position: 'absolute', inset: 0, perspective: 1500, perspectiveOrigin: '34% 48%'}}>
        <div
          style={{
            position: 'absolute',
            left: 108,
            top: 84,
            width: 1064,
            height: 556,
            borderRadius: 20,
            transform: `rotateY(${-15 + Math.sin(frame / 64) * 1.4 + (1 - boardIn) * 8}deg) rotateX(${4.5 + Math.cos(frame / 82) * 0.7}deg) translateY(${(1 - boardIn) * 40 + Math.sin(frame / 52) * 2}px)`,
            transformStyle: 'preserve-3d',
            border: '13px solid #654A34',
            boxSizing: 'border-box',
            background: 'linear-gradient(132deg,#28352F 0%,#1C2723 52%,#16201D 100%)',
            boxShadow: '0 70px 130px rgba(0,0,0,.72), inset 0 0 100px rgba(0,0,0,.5), 0 0 0 1px rgba(255,236,206,.14) inset',
            opacity: boardIn,
            overflow: 'hidden',
          }}
        >
          <div
            aria-hidden
            style={{
              position: 'absolute',
              inset: 0,
              opacity: 0.17,
              backgroundImage:
                'linear-gradient(rgba(255,255,255,.24) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.24) 1px, transparent 1px)',
              backgroundSize: '72px 72px',
            }}
          />
          {/* 粉笔灰的斜向反光 */}
          <div
            aria-hidden
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(108deg, rgba(255,255,255,.10) 0%, transparent 42%, rgba(255,255,255,.05) 70%, transparent 100%)',
            }}
          />

          {/* 标题：从左往右写 */}
          <div
            style={{
              position: 'absolute',
              left: 52,
              top: 40,
              fontFamily: theme.serif,
              fontSize: 44,
              letterSpacing: 3,
              color: theme.chalk,
              textShadow: '0 2px 0 rgba(0,0,0,.35)',
              clipPath: `inset(0 ${100 - 100 * ease(frame, 4, 34)}% 0 0)`,
            }}
          >
            {heading}
          </div>
          <div
            style={{
              position: 'absolute',
              left: 56,
              top: 104,
              height: 2,
              width: 300 * ease(frame, 32, 56),
              background: 'rgba(243,234,218,.35)',
            }}
          />

          {/* 板书行：逐行写 + 讲到就变亮 + 黄色粉笔划线 */}
          {rows.map((r, i) => {
            const w = soft(frame, r.cue, r.cue + 30);
            const lit = active === i ? 1 : active > i ? 0.46 : 0.62;
            return (
              <div key={r.text} style={{position: 'absolute', left: 62, top: 170 + i * 96, width: 940}}>
                <div style={{display: 'flex', alignItems: 'baseline', gap: 14}}>
                  <span
                    style={{
                      fontFamily: theme.serif,
                      fontSize: 38,
                      letterSpacing: 2,
                      color: theme.chalk,
                      opacity: lit * (0.4 + 0.6 * Math.min(1, w * 1.4)),
                      clipPath: `inset(0 ${100 - 100 * w}% 0 0)`,
                      filter: `blur(${(1 - w) * 2}px) drop-shadow(0 0 ${12 * (lit - 0.46)}px rgba(255,232,186,.4))`,
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {r.text}
                  </span>
                  {r.note && (
                    <span style={{fontFamily: theme.sans, fontSize: 16, color: 'rgba(243,234,218,.5)', opacity: w}}>{r.note}</span>
                  )}
                </div>
                {/* 黄色粉笔高亮：讲到这一行时划过去 */}
                <div
                  style={{
                    marginTop: 6,
                    height: 8,
                    width: 0,
                    borderRadius: 4,
                    background: 'linear-gradient(90deg, rgba(232,163,61,.85), rgba(232,163,61,.25))',
                    boxShadow: '0 0 16px rgba(232,163,61,.45)',
                    transform: `scaleX(${soft(frame, r.cue + 22, r.cue + 44)})`,
                    transformOrigin: 'left center',
                    opacity: lit,
                  }}
                />
              </div>
            );
          })}

          {footer && (
            <div
              style={{
                position: 'absolute',
                left: 66,
                bottom: 42,
                fontFamily: theme.serif,
                fontSize: 19,
                letterSpacing: 2,
                color: 'rgba(243,234,218,.6)',
                opacity: ease(frame, 118, 142),
              }}
            >
              {footer}
            </div>
          )}
        </div>

        {/* 粉笔槽 + 粉笔 + 板擦 */}
        <div
          style={{
            position: 'absolute',
            left: 96,
            bottom: 58,
            width: 1092,
            height: 40,
            borderRadius: 14,
            transform: 'rotateX(52deg)',
            background: 'linear-gradient(180deg,#4A3826,#2A1E14 72%,#1A120C)',
            boxShadow: '0 26px 44px rgba(0,0,0,.6), inset 0 2px 0 rgba(255,235,200,.18)',
            opacity: boardIn,
          }}
        >
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                position: 'absolute',
                top: 4,
                left: 120 + i * 96,
                width: 54,
                height: 10,
                borderRadius: 5,
                background: ['#F2E4C4', '#F4D07E', '#D9E2D3'][i],
                boxShadow: '0 3px 6px rgba(0,0,0,.5)',
              }}
            />
          ))}
          <div
            style={{
              position: 'absolute',
              top: -4,
              right: 150,
              width: 96,
              height: 18,
              borderRadius: 6,
              background: 'linear-gradient(180deg,#6E5A44,#3C2E21)',
              boxShadow: '0 6px 10px rgba(0,0,0,.5)',
            }}
          />
        </div>
        <div
          aria-hidden
          style={{
            position: 'absolute',
            left: 170,
            bottom: 34,
            width: 950,
            height: 70,
            background: 'radial-gradient(closest-side, rgba(0,0,0,.55), transparent)',
            filter: 'blur(16px)',
          }}
        />
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── 05 卷纸：从上往下展开 + 逐句划亮 ───────────────────────── */

export type SheetLine = {before: string; keyword: string; after: string; cue: number};

const Marker: React.FC<{frame: number; cue: number; color: string; children: string}> = ({frame, cue, color, children}) => {
  const w = soft(frame, cue, cue + 16);
  return (
    <span style={{position: 'relative', display: 'inline-block', padding: '0 3px'}}>
      <span
        aria-hidden
        style={{
          position: 'absolute',
          left: -2,
          right: -2,
          bottom: 2,
          height: '68%',
          borderRadius: 6,
          background: `linear-gradient(90deg, ${color}, ${color}bb)`,
          opacity: 0.86,
          transform: `scaleX(${w})`,
          transformOrigin: 'left center',
          boxShadow: `0 0 ${20 * w}px ${color}55`,
          mixBlendMode: 'multiply',
        }}
      />
      {/* 划过后向右延伸的笔触余韵 */}
      {w > 0.85 && (
        <span
          aria-hidden
          style={{
            position: 'absolute',
            left: 0,
            bottom: -2,
            width: `${Math.min(100, 100)}%`,
            height: 2,
            background: color,
            opacity: 0.6,
          }}
        />
      )}
      <span style={{position: 'relative'}}>{children}</span>
    </span>
  );
};

export const ScrollSheet: React.FC<{
  title: string;
  eyebrow?: string;
  lines: SheetLine[];
  start?: number;
}> = ({title, eyebrow, lines, start = 0}) => {
  const frame = useCurrentFrame();
  const W = 1004;
  const H = 520;
  const open = ease(frame, start + 4, start + 46);
  const radius = 34 * Math.sqrt(Math.max(0, 1 - open));
  const textSize = Math.min(34, 640 / Math.max(1, ...lines.map((l) => Array.from(l.before + l.keyword + l.after).length)));
  const rowH = Math.min(84, 250 / Math.max(1, lines.length));
  const openPx = H * open;
  const current = lines.reduce((acc, l, i) => (frame >= l.cue ? i : acc), -1);

  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(ellipse at 26% 16%, #35514C 0%, #1C3134 52%, #0E2126 100%)',
        }}
      />
      <div
        aria-hidden
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0.3,
          background:
            'repeating-linear-gradient(104deg, rgba(255,246,222,.10) 0 1px, transparent 1px 5px), repeating-linear-gradient(14deg, rgba(255,246,222,.09) 0 1px, transparent 1px 6px)',
        }}
      />

      <div
        style={{
          position: 'absolute',
          left: (1280 - W) / 2,
          top: 96,
          width: W,
          height: H,
          transformOrigin: '50% 0%',
          transform: `translateY(${(1 - ease(frame, start, start + 22, settle)) * -40}px) rotate(${-1.2 + open * 1.2}deg)`,
        }}
      >
        {/* 纸张投影（先铺一层，避免阴影被裁掉） */}
        <div
          style={{
            position: 'absolute',
            left: 2,
            top: 8,
            width: W - 4,
            height: openPx,
            borderRadius: '10px 12px 14px 10px',
            boxShadow: '0 36px 70px rgba(2,14,18,.55), 0 10px 20px rgba(2,14,18,.36)',
          }}
        />
        <div
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: W,
            height: H,
            clipPath: `inset(0 0 ${100 - open * 100}% 0)`,
            borderRadius: '10px 12px 14px 10px',
            background: 'linear-gradient(106deg,#EFE1BC 0%,#F8EFD6 26%,#F2E6C6 66%,#E7D9B4 100%)',
            overflow: 'hidden',
          }}
        >
          {/* 纸张纹理 + 装订线 */}
          <div
            aria-hidden
            style={{
              position: 'absolute',
              inset: 0,
              opacity: 0.55,
              background: 'repeating-linear-gradient(0deg, rgba(140,120,86,.10) 0 1px, transparent 1px 4px)',
            }}
          />
          <div style={{position: 'absolute', left: 36, top: 0, bottom: 0, width: 1, background: 'rgba(176,132,102,.5)'}} />
          <div style={{position: 'absolute', left: 41, top: 0, bottom: 0, width: 1, background: 'rgba(176,132,102,.2)'}} />

          <div style={{position: 'absolute', left: 74, top: 38, fontFamily: theme.sans, fontSize: 18, letterSpacing: 3, color: '#6E7C6E'}}>{eyebrow}</div>
          <div
            style={{
              position: 'absolute',
              left: 70,
              top: 64,
              fontFamily: theme.serif,
              fontWeight: 700,
              fontSize: Math.min(72, 560 / Math.max(1, Array.from(title).length)),
              letterSpacing: 4,
              color: '#263B39',
              lineHeight: 1.2,
            }}
          >
            {title}
          </div>
          <div style={{position: 'absolute', left: 74, top: 168, right: 60, height: 1, background: 'linear-gradient(90deg,#718174,#A2AA94 78%,transparent)'}} />

          {lines.map((l, i) => {
            const appear = soft(frame, 14 + i * 9, 34 + i * 9);
            const lit = current === i ? 1 : current > i ? 0.62 : 0.86;
            return (
              <div
                key={i}
                style={{
                  position: 'absolute',
                  left: 74,
                  top: 200 + i * rowH,
                  width: 660,
                  height: rowH,
                  lineHeight: `${rowH}px`,
                  fontFamily: '"KaiTi", "STKaiti", "FangSong", serif',
                  fontSize: textSize,
                  color: '#263B39',
                  whiteSpace: 'nowrap',
                  opacity: appear * lit,
                  borderBottom: '1px solid rgba(110,127,110,.20)',
                }}
              >
                {l.before}
                <Marker frame={frame} cue={l.cue} color="#F0C64F">
                  {l.keyword}
                </Marker>
                {l.after}
              </div>
            );
          })}

          {/* 右侧速写框：随讲到的句子轮换色块 */}
          <div
            style={{
              position: 'absolute',
              right: 54,
              top: 196,
              width: 232,
              height: 246,
              borderRadius: 16,
              overflow: 'hidden',
              border: '7px solid #FBF3DD',
              boxShadow: '0 18px 34px rgba(20,30,26,.35), 0 0 0 1px rgba(120,100,70,.25)',
              opacity: ease(frame, 48, 76),
              transform: `rotate(${-3 + 1.6 * ease(frame, 48, 76)}deg)`,
            }}
          >
            <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(150deg,#4E7268 0%,#2E4C48 46%,#1D3536 100%)'}}>
              <div
                aria-hidden
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'radial-gradient(120% 70% at 22% 12%, rgba(255,214,150,.55), transparent 58%)',
                  transform: `translateX(${Math.sin(frame / 40) * 10}px)`,
                }}
              />
            </div>
            <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'flex-end', padding: 12}}>
              <span style={{fontFamily: theme.serif, fontSize: 17, letterSpacing: 2, color: 'rgba(255,244,223,.86)'}}>窗边速写</span>
            </div>
          </div>
        </div>

        {/* 展开前沿的纸卷（卷着的那一根） */}
        {radius > 0.6 && (
          <div
            style={{
              position: 'absolute',
              left: -2,
              top: openPx - radius * 0.9,
              width: W + 4,
              height: radius * 2.1,
              opacity: Math.min(1, radius / 2.4),
              borderRadius: '6px 10px 10px 6px',
              background: 'linear-gradient(180deg,#B29A76 0%,#E6D3AC 22%,#F8EDCF 46%,#E7D6B4 68%,#B39B76 100%)',
              boxShadow: `0 ${Math.round(radius * 0.5)}px ${Math.round(radius * 0.7)}px rgba(12,26,26,.5), inset 0 0 0 1px rgba(255,250,225,.4)`,
            }}
          >
            <div
              style={{
                position: 'absolute',
                right: 4,
                top: '50%',
                width: radius * 0.9,
                height: radius * 2.1,
                transform: 'translateY(-50%)',
                borderRadius: '50%',
                background: 'radial-gradient(closest-side, #D9C6A0, #A98F6C 68%, #806C52 100%)',
                boxShadow: 'inset -4px 0 8px rgba(80,60,40,.4)',
              }}
            />
          </div>
        )}
      </div>
    </AbsoluteFill>
  );
};

/** 画面统一的四周压暗，保证任何动态元素都落在同一个光谱里 */
export const Vignette: React.FC<{strength?: number}> = ({strength = 0.55}) => (
  <div
    aria-hidden
    style={{
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      background: `radial-gradient(120% 95% at 50% 48%, transparent 46%, rgba(4,10,12,${strength}) 100%)`,
    }}
  />
);

export {Img};
