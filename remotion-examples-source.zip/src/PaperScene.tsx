import React, {useId} from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';

export type PaperLine = {
  before: string;
  keyword: string;
  after: string;
  /** Frame relative to the beginning of this scene. */
  cue: number;
};

export type PaperSceneProps = {
  title?: string;
  eyebrow?: string;
  lines?: PaperLine[];
};

export const defaultPaperProps = {
  title: '随车手记',
  eyebrow: '杭州东　经嘉兴南　至上海虹桥',
  lines: [
    {before: '离开杭州，', keyword: '站台灯', after: '在车窗里拉长。', cue: 48},
    {before: '驶过嘉兴，', keyword: '河面', after: '映出一排暖灯。', cue: 77},
    {before: '临近上海，', keyword: '楼群', after: '从夜色里浮出来。', cue: 106},
  ],
} satisfies PaperSceneProps;

const WIDTH = 1014;
const HEIGHT = 508;
const ink = '#263b39';
const handwriting = '"KaiTi", "STKaiti", "FangSong", "SimSun", serif';
const brush = '"STXingkai", "KaiTi", "STKaiti", serif';
const travel = Easing.bezier(0.31, 0.02, 0.18, 1);
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// A small repeatable tile keeps the paper grain fixed to the sheet as it moves.
const fibers = Array.from({length: 90}, (_, i) => {
  const x = (67 * i + 31 * i * i) % 137;
  const y = (41 * i + 7 * i * i) % 103;
  return `M${x} ${y}l${1 + (i % 4)} ${i % 3 - 1}`;
}).join('');
const grain = `url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="137" height="103"><path d="' + fibers + '" fill="none" stroke="#6a543c" stroke-opacity=".16" stroke-width=".65" stroke-linecap="round"/></svg>')}")`;

const RiverSketch = () => {
  const clip = 'sketch' + useId().replace(/[^a-zA-Z0-9]/g, '');
  const hatch = Array.from({length: 26}, (_, i) => {
    const x = 7 + i * 8.2;
    const y = 119 + ((i * 11) % 14);
    return <path key={i} d={`M${x} ${y}l${4 + (i % 8)} -2m-3 6l${3 + (i % 5)} -1`}/>;
  });
  return (
    <svg width="236" height="181" viewBox="0 0 236 181" fill="none" aria-hidden>
      <defs><clipPath id={clip}><rect x="4" y="5" width="228" height="164" rx="3"/></clipPath></defs>
      <g clipPath={`url(#${clip})`}>
        <circle cx="162" cy="40" r="20" fill="#bb7255" opacity=".76"/>
        <g stroke="#728077" strokeLinecap="round" opacity=".7">
          <path d="M-6 84Q12 73 32 77q19-22 39-13q11-13 25 0q13-17 28-12q15-23 30-12M142 59q18-10 28-4q22-20 32-15q22 2 38-12"/>
          <path d="M5 91q18-12 36-10q21-15 37-11m2-3 9 1m31-7q25-16 40-17m20 18q27-11 41-9"/>
        </g>
        <path d="M-5 105l20-6 16 1 12-5 16 4 21-9 16 4 11-5 14 3 22-9 14 5 23-9 16 4 18-8 27 6v28H-5z" fill="#6e8178" opacity=".73"/>
        <path d="M-2 110Q37 100 76 104t67-5q37-11 96-4v9q-38-2-74 5q-40 7-79 2q-37-1-88 7z" fill="#385750"/>
        <path d="M-3 122q32-12 74-11m56-1q41-5 62-6m16 1 22-4" stroke="#374b45" strokeWidth="2"/>
        <g fill="#3f534d" stroke="#3f534d" strokeLinejoin="round">
          <path d="M14 99V82l15-6 17 9v13z" fill="#ded3af"/>
          <path d="M9 84q9-4 18-12q11 8 24 10l-4 4q-11-2-19-9l-13 8z"/>
          <path d="M38 101V86l13-5 11 7v10" fill="#d9d1b1"/>
          <path d="M35 87q7-3 15-10q7 6 15 8l-3 3-12-6-10 6z"/>
          <path d="M25 99V88h5v11m13-7h3v5h-3z"/>
          <path d="M77 101q2-12 2-18l-3-6 4 2 2-11 2 12 4-5-4 9v17m111-8q1-8 0-17l-5-10 6 4 2-14 2 13 4-5-3 12 1 16"/>
          <path d="M69 81q-1-5 5-8q0-8 5-8q3-9 6-2q8 2 7 9q6 5 1 9zM185 67q0-6 4-8q-1-7 6-8q2-7 5-2q8 1 7 8q3 3 3 9z"/>
        </g>
        <g stroke="#576f66" strokeWidth="1.15" strokeLinecap="round">{hatch}</g>
        <path d="M32 141q17-4 32-3m-9 5 17-1m5-9 18 1m11 10 30-3m-15 6 15-2m22-16 22-3m7 4 15-3" stroke="#69796b" strokeLinecap="round"/>
        <path d="M129 125q10-1 24-5q-3 6-18 8z" fill="#344944"/>
        <path d="M140 124l5-12 2 10m0 0 7 4" stroke="#344944" strokeWidth="1.3"/>
        <path d="M9 153c28-6 52-2 72 0m94-14q30-4 53-3" stroke="#869083" strokeLinecap="round"/>
      </g>
    </svg>
  );
};

const Mark = ({children, frame, cue, color}: {children: string; frame: number; cue: number; color: string}) => {
  const drawn = interpolate(frame, [cue, cue + 13], [0, 1], {...clamp, easing: travel});
  return (
    <span style={{position: 'relative', display: 'inline-block'}}>
      <svg viewBox="0 0 100 20" preserveAspectRatio="none" aria-hidden style={{position: 'absolute', left: '-4%', bottom: '7%', width: '109%', height: '55%', clipPath: `inset(0 ${(1 - drawn) * 100}% 0 0)`}}>
        <path d="M1 5Q21 2 41 3T74 2L97 1 99 4 97 8 100 12 98 16Q70 15 46 17T2 19L4 15 0 12 2 9Z" fill={color} opacity=".83"/>
        <path d="M4 17Q32 13 66 13T97 12" fill="none" stroke={color} strokeWidth="2.3" opacity=".76"/>
      </svg>
      <span style={{position: 'relative'}}>{children}</span>
    </span>
  );
};

export const PaperScene: React.FC<PaperSceneProps> = ({
  title = defaultPaperProps.title,
  eyebrow = defaultPaperProps.eyebrow,
  lines = defaultPaperProps.lines,
}) => {
  const frame = useCurrentFrame();
  const opened = interpolate(frame, [6, 45], [0, 1], {...clamp, easing: travel});
  const flatHeight = 19 + (HEIGHT - 19) * opened;
  // Radius falls with the square root of the remaining wound paper length.
  const radius = 39 * Math.sqrt(1 - opened);
  const drop = interpolate(frame, [0, 14, 32, 49], [-104, 7, -2, 0], {...clamp, easing: Easing.out(Easing.cubic)});
  const angle = interpolate(frame, [0, 21, 46, 143], [-5.3, -2.1, -1.8, -1.35], clamp);
  const zoom = interpolate(frame, [44, 143], [1, 1.021], clamp);
  const curlOpacity = Math.min(1, radius / 3);
  const maxChars = Math.max(1, ...lines.map(line => Array.from(line.before + line.keyword + line.after).length));
  const textSize = Math.min(36, 621 / maxChars, 145 / Math.max(1, lines.length));
  const lineHeight = Math.min(62, 218 / Math.max(1, lines.length));
  return (
    <AbsoluteFill style={{overflow: 'hidden', background: 'radial-gradient(ellipse at 31% 19%, #36514c, #1e3435 54%, #102329 100%)'}}>
      <div style={{position: 'absolute', inset: 0, opacity: .34, backgroundImage: grain, backgroundSize: '168px 128px', mixBlendMode: 'screen'}}/>
      <div style={{position: 'absolute', left: '65%', width: '75%', top: '-30%', bottom: '-28%', transform: 'rotate(29deg)', opacity: .2, background: 'linear-gradient(90deg,transparent 14%,#0a1a21 18%,#0a1a21 23%,transparent 27%,transparent 64%,#0a1a21 68%,#0a1a21 73%,transparent 77%)'}}/>
      <div style={{position: 'absolute', left: (1280 - WIDTH) / 2, top: 111, width: WIDTH, height: HEIGHT, transformOrigin: '50% 18%', transform: `translateY(${drop}px) rotate(${angle}deg) scale(${zoom})`}}>
        <div style={{position: 'absolute', width: WIDTH - 6, left: 4, top: 7, height: flatHeight, borderRadius: 10, boxShadow: '0 24px 52px 5px rgba(3,15,19,.42), 0 9px 17px rgba(5,20,20,.34)'}}/>
        <div style={{position: 'absolute', inset: '0 0 auto 0', height: flatHeight, overflow: 'hidden', borderRadius: '8px 10px 11px 7px', background: 'linear-gradient(108deg,#eee1b9 0%,#f6ecd0 21%,#f1e5c5 65%,#e7d9b4 100%)'}}>
          <div style={{position: 'absolute', inset: 0, backgroundImage: grain}}/>
          <div style={{position: 'absolute', left: 39, width: 1, top: 0, height: HEIGHT, background: '#c59b80', opacity: .49}}/>
          <div style={{position: 'absolute', left: 44, width: 1, top: 0, height: HEIGHT, background: '#b9987d', opacity: .21}}/>
          <div style={{position: 'absolute', left: 72, top: 40, fontFamily: handwriting, color: '#607067', fontSize: 20, letterSpacing: 2.5}}>{eyebrow}</div>
          <div style={{position: 'absolute', left: 70, top: 66, width: 650, fontFamily: brush, fontSize: Math.min(89, 594 / Math.max(1, Array.from(title).length)), color: ink, lineHeight: 1.2, letterSpacing: 4, whiteSpace: 'nowrap'}}>{title}</div>
          <div style={{position: 'absolute', left: 73, top: 182, right: 60, height: 1, background: 'linear-gradient(90deg,#718174,#a2aa94 80%,transparent)', transform: 'rotate(-.13deg)'}}/>
          <div style={{position: 'absolute', left: 73, top: 215, width: 626, color: ink, fontFamily: handwriting, fontSize: textSize, fontWeight: 500}}>
            {lines.map((line, i) => (
              <div key={i} style={{height: lineHeight, lineHeight: `${lineHeight}px`, whiteSpace: 'nowrap', borderBottom: '1px solid rgba(110,127,110,.22)'}}>
                {line.before}<Mark frame={frame} cue={line.cue} color={['#eac452', '#dbb743', '#e8b64e'][i % 3]}>{line.keyword}</Mark>{line.after}
              </div>
            ))}
          </div>
          <div style={{position: 'absolute', right: 42, top: 198, transform: 'rotate(-3deg)'}}>
            <RiverSketch/>
            <div style={{fontFamily: brush, color: '#5c6b5c', fontSize: 27, textAlign: 'center', transform: 'rotate(-4deg)', marginTop: -14}}>窗边速写</div>
          </div>
          <div style={{position: 'absolute', right: 73, top: 69, width: 56, height: 61, transform: 'rotate(4deg)', border: '3px solid #a84735', boxShadow: 'inset 0 0 0 2px #ebd9af, inset 0 0 0 3px #b3654b', borderRadius: '7px 6px 10px 5px', color: '#aa4937', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: brush, fontSize: 26, lineHeight: .9, writingMode: 'vertical-rl', letterSpacing: 1}}>夜行</div>
          <div style={{position: 'absolute', width: WIDTH, height: 22, top: HEIGHT - 22, background: 'linear-gradient(0deg,rgba(133,108,69,.09),transparent)'}}/>
        </div>
        {/* The raised roll casts a moving shadow. Its end cap exposes the winding. */}
        {radius > .04 && <div style={{position: 'absolute', left: -1, top: flatHeight - radius * .75, width: WIDTH + 2, height: radius * 2, opacity: curlOpacity}}>
          <div style={{position: 'absolute', left: 4, top: radius * 1.52, width: WIDTH - 2, height: Math.max(1, radius * .67), borderRadius: '50%', boxShadow: `2px ${radius * .30}px ${radius * .46}px rgba(16,27,23,.58)`, backgroundColor: 'rgba(63,59,40,.35)'}}/>
          <div style={{position: 'absolute', inset: 0, borderRadius: `4px ${radius * .48}px ${radius * .48}px 5px`, background: 'linear-gradient(180deg,#ac9570 0%,#d4bd95 6%,#ead9b3 18%,#f7edcf 36%,#efe0be 52%,#c6ae86 77%,#8b7557 94%,#baa381 100%)', boxShadow: 'inset 1px 1px 2px rgba(255,249,219,.75)'}}>
            <div style={{position: 'absolute', inset: 0, borderRadius: 'inherit', backgroundImage: grain, opacity: .77}}/>
          </div>
          <svg width={Math.max(1, radius * .55)} height={Math.max(1, radius * 2)} viewBox="0 0 26 80" preserveAspectRatio="none" style={{position: 'absolute', right: -radius * .07}}>
            <ellipse cx="13" cy="40" rx="12" ry="39" fill="#b29a76" stroke="#806d52" strokeWidth="1.6"/>
            <path d="M12 2C30 9 26 80 12 77C-3 73 1 7 14 9C26 12 23 70 13 70C3 69 5 17 14 17C21 20 21 63 13 62C7 61 8 26 14 26C19 27 18 54 13 53C10 53 10 35 14 36" fill="none" stroke="#79694f" strokeWidth="1.45"/>
          </svg>
        </div>}
      </div>
    </AbsoluteFill>
  );
};
