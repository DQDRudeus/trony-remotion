import React from 'react';
import {ThiefCode, thiefDefaults} from './ThiefCode';
import {AbsoluteFill, Composition, Folder, Series} from 'remotion';
import {z} from 'zod';
import {defaultCutaway, defaultOpening, FilmOpening, PresenterCutaway, Sound} from './FilmScenes';
import {defaultPaperProps, PaperScene} from './PaperScene';
import {RouteScene, routeDefaults} from './RouteScene';
import {CircleAvatarScene, DataBody, SideBoardBody} from './Extras';
import {PaperInsert} from './TronyPaper';
import {
  AnimBoardScene,
  AnimFlowScene,
  AnimMediaScene,
  AnimScrollScene,
  AnimTitleScene,
  animLengths,
  animTotal,
  XiaolinAnimPack,
} from './AnimScenes';

const video = {width: 1280, height: 720, fps: 24};
const lengths = {opening: 132, cutaway: 144, route: 144, paper: 144};
const total = lengths.opening + lengths.cutaway + lengths.route + lengths.paper;
const mediaPath = z.string().min(1).describe('public 文件夹内的媒体相对路径');
const openingSchema = z.object({
  title: z.string().min(1).max(8),
  routeCaption: z.string(),
  titleCaption: z.string(),
  firstClip: mediaPath,
  secondClip: mediaPath,
});
const cutawaySchema = z.object({
  photo: mediaPath,
  firstClip: mediaPath,
  secondClip: mediaPath,
  presenterVideo: z.string().describe('可选，public 内的口播视频，保留原声'),
  side: z.enum(['left', 'right', 'top', 'bottom']).describe('第二次换位后的人物位置'),
  punchIn: z.number().min(1).max(1.35),
  cue: z.number().int().min(75).max(126).describe('口播推近的起始帧'),
  sound: z.boolean(),
});
const routeSchema = z.object({
  stations: z.tuple([z.string(), z.string(), z.string()]),
  cues: z.tuple([z.number().int().min(0).max(141), z.number().int().min(1).max(142), z.number().int().min(2).max(143)]).describe('依次递增的三个到站帧'),
});
const paperSchema = z.object({
  title: z.string(), eyebrow: z.string(),
  lines: z.array(z.object({before:z.string(), keyword:z.string(), after:z.string(), cue:z.number().int().min(0).max(132)})).min(1).max(3),
});
const sampleSchema = z.object({opening:openingSchema, cutaway:cutawaySchema, route:routeSchema, paper:paperSchema});
const defaults = {opening:defaultOpening, cutaway:defaultCutaway, route:routeDefaults, paper:defaultPaperProps};

const NightTrain: React.FC<typeof defaults> = ({opening, cutaway, route, paper}) => (
  <AbsoluteFill style={{backgroundColor:'#142c2e'}}>
    <Series>
      <Series.Sequence durationInFrames={lengths.opening} name="两段叠化 · 宽银幕片头"><FilmOpening {...opening}/></Series.Sequence>
      <Series.Sequence durationInFrames={lengths.cutaway} name="梗图 · 换位 · 推近"><PresenterCutaway {...cutaway}/></Series.Sequence>
      <Series.Sequence durationInFrames={lengths.route} name="侧视路线 · 到站点亮">
        <RouteScene {...route}/>
        {cutaway.sound && <Sound at={route.cues[2]} kind="pop" volume={.30}/>}
      </Series.Sequence>
      <Series.Sequence durationInFrames={lengths.paper} name="卷纸展开 · 逐句划亮"><PaperScene {...paper}/></Series.Sequence>
    </Series>
  </AbsoluteFill>
);

const xiaolinTotal = 132 + 144 * 5;

const XiaolinPack: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#0b1618'}}>
    <Series>
      <Series.Sequence durationInFrames={132} name="01 叠化 · 宽银幕"><FilmOpening {...defaultOpening}/></Series.Sequence>
      <Series.Sequence durationInFrames={144} name="02 梗图 · 换位 · 推近"><PresenterCutaway {...defaultCutaway}/></Series.Sequence>
      <Series.Sequence durationInFrames={144} name="03 数据图表"><DataBody/></Series.Sequence>
      <Series.Sequence durationInFrames={144} name="04 侧视黑板"><SideBoardBody/></Series.Sequence>
      <Series.Sequence durationInFrames={144} name="05 路线线索"><RouteScene {...routeDefaults}/></Series.Sequence>
      <Series.Sequence durationInFrames={144} name="06 卷纸 · 划亮"><PaperScene {...defaultPaperProps}/></Series.Sequence>
    </Series>
  </AbsoluteFill>
);

export const Studio: React.FC = () => <>
  <Composition id="ThiefCode" component={ThiefCode} width={1920} height={1080} fps={30} durationInFrames={360}
    defaultProps={thiefDefaults} schema={z.object({
      title: z.string().min(1).max(4), english: z.string().max(16), effort: z.string().min(3).max(8),
      upperLabel: z.string().max(4), lowerLabel: z.string().max(4),
      revealAt: z.number().int().min(30).max(90).describe('右侧卡片入场帧，30 帧等于 1 秒'),
      mimicCue: z.number().int().min(125).max(180), openCue: z.number().int().min(200).max(260),
      sound: z.boolean(), sideView: z.boolean(), transparentBackground: z.boolean(),
    })}/>
  <Composition id="ThiefCodeOverlay" component={ThiefCode} width={1920} height={1080} fps={30} durationInFrames={360}
    defaultProps={{...thiefDefaults, transparentBackground: true}}
    calculateMetadata={() => ({defaultCodec: 'prores', defaultVideoImageFormat: 'png', defaultPixelFormat: 'yuva444p10le', defaultProResProfile: '4444'})}/>
  <Composition {...video} id="NightTrain" component={NightTrain} schema={sampleSchema} defaultProps={defaults} durationInFrames={total}/>
  <Folder name="Scenes">
    <Composition {...video} id="FilmOpening" component={FilmOpening} schema={openingSchema} defaultProps={defaultOpening} durationInFrames={lengths.opening}/>
    <Composition {...video} id="PresenterCutaway" component={PresenterCutaway} schema={cutawaySchema} defaultProps={defaultCutaway} durationInFrames={lengths.cutaway}/>
    <Composition {...video} id="RouteMap" component={RouteScene} schema={routeSchema} defaultProps={routeDefaults} durationInFrames={lengths.route}/>
    <Composition {...video} id="PaperHighlight" component={PaperScene} schema={paperSchema} defaultProps={defaultPaperProps} durationInFrames={lengths.paper}/>
    <Composition id="PaperInsert" component={PaperInsert} width={1920} height={1080} fps={30} durationInFrames={240}/>
    <Composition id="PaperInsertOverlay" component={PaperInsert} width={1920} height={1080} fps={30} durationInFrames={240}
      defaultProps={{transparentBackground: true}}
      calculateMetadata={() => ({defaultCodec: 'prores', defaultVideoImageFormat: 'png', defaultPixelFormat: 'yuva444p10le', defaultProResProfile: '4444'})}/>
  </Folder>
  <Folder name="xiaolin-extras">
    <Composition {...video} id="DataCharts" component={DataBody} durationInFrames={144}/>
    <Composition {...video} id="SideBoard" component={SideBoardBody} durationInFrames={144}/>
    <Composition {...video} id="CircleAvatar" component={CircleAvatarScene} durationInFrames={144}/>
  </Folder>
  <Composition {...video} id="XiaolinPack" component={XiaolinPack} durationInFrames={xiaolinTotal}/>
  <Folder name="Anim">
    <Composition {...video} id="AnimTitle" component={AnimTitleScene} durationInFrames={animLengths.title}/>
    <Composition {...video} id="AnimFlow" component={AnimFlowScene} durationInFrames={animLengths.flow}/>
    <Composition {...video} id="AnimMedia" component={AnimMediaScene} durationInFrames={animLengths.media}/>
    <Composition {...video} id="AnimBoard" component={AnimBoardScene} durationInFrames={animLengths.board}/>
    <Composition {...video} id="AnimScroll" component={AnimScrollScene} durationInFrames={animLengths.scroll}/>
  </Folder>
  <Composition {...video} id="XiaolinAnim" component={XiaolinAnimPack} durationInFrames={animTotal}/>
</>;
