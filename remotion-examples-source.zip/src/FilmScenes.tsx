import React from 'react';
import {AbsoluteFill, Html5Audio, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';

const serif = '"Noto Serif SC", "STSong", "SimSun", serif';
const sans = '"Microsoft YaHei", "Noto Sans SC", sans-serif';
const mono = '"Consolas", monospace';
const frameStyle: React.CSSProperties = {height: '100%', width: '100%', objectFit: 'cover'};
const shadow = '0 20px 46px #04111470, 0 3px 9px #04111445';
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const progress = (frame: number, start: number, end: number) => {
  const t = interpolate(frame, [start, end], [0, 1], clamp);
  return t * t * (3 - 2 * t);
};

export const defaultOpening = {
  title: '夜行',
  routeCaption: '杭州东　—　上海虹桥',
  titleCaption: 'JIANGNAN NIGHT TRAIN',
  firstClip: 'media/rail-station.mp4',
  secondClip: 'media/rail-window.mp4',
};

export const Sound: React.FC<{at: number; kind: 'photo' | 'cut' | 'pop'; volume?: number}> = ({at, kind, volume = 0.6}) => (
  <Sequence from={at} durationInFrames={12} layout="none">
    <Html5Audio src={staticFile('sfx/' + kind + '.wav')} volume={volume} />
  </Sequence>
);

export const FilmOpening: React.FC<typeof defaultOpening> = ({title, routeCaption, titleCaption, firstClip, secondClip}) => {
  const frame = useCurrentFrame();
  const blend = progress(frame, 10, 47);
  const matte = 92 * progress(frame, 11, 54);
  const chars = Array.from(title);
  const detail = progress(frame, 56, 82);
  const glyphSize = Math.min(178, 440 / Math.max(1, chars.length));
  return (
    <AbsoluteFill style={{backgroundColor: '#0b1618', overflow: 'hidden'}}>
      {frame < 48 && <OffthreadVideo src={staticFile(firstClip)} muted style={frameStyle} />}
      <AbsoluteFill style={{opacity: blend}}>
        <OffthreadVideo src={staticFile(secondClip)} muted style={frameStyle} />
      </AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(90deg,rgba(4,17,19,.56),rgba(4,17,19,.16) 50%,transparent 87%)', opacity: blend}} />
      <div style={{position: 'absolute', left: 100, top: 204, color: '#fff1d6'}}>
        <div style={{display: 'flex', gap: 14, alignItems: 'center', font: '15px ' + mono, letterSpacing: 4, opacity: progress(frame, 27, 53)}}>
          <span style={{width: 38, height: 3, background: '#ef9a68'}} />{titleCaption}
        </div>
        <div style={{display: 'flex', height: 207, alignItems: 'center', gap: 14, marginLeft: -5}}>
          {chars.map((char, i) => {
            const delay = (i / Math.max(1, chars.length - 1)) * 11;
            const t = progress(frame, 24 + delay, 74 + delay);
            const edge = -24 + t * 155;
            return <span key={i} style={{fontFamily: serif, fontWeight: 600, fontSize: glyphSize, lineHeight: 1.1, display: 'inline-block', opacity: Math.min(1, t * 2), transform: 'translate(' + ((1 - t) * 14) + 'px,' + ((1 - t) * 8) + 'px)', textShadow: '1px 2px 9px #10282d88', maskImage: 'linear-gradient(108deg, black ' + (edge - 22) + '%, transparent ' + edge + '%)'}}>{char}</span>;
          })}
        </div>
        <div style={{marginTop: 6, fontFamily: sans, fontSize: 20, letterSpacing: 4, opacity: detail}}>{routeCaption}</div>
      </div>
      {['top', 'bottom'].map((edge) => <div key={edge} style={{position: 'absolute', left: 0, right: 0, [edge]: 0, height: matte, background: '#0a1010'}} />)}
    </AbsoluteFill>
  );
};

export const defaultCutaway = {
  photo: 'media/reaction.jpg',
  firstClip: 'media/rail-station.mp4',
  secondClip: 'media/rail-window.mp4',
  presenterVideo: '',
  side: 'right' as 'left' | 'right' | 'top' | 'bottom',
  punchIn: 1.12,
  cue: 93,
  sound: true,
};

// An illustrated stand-in keeps the punch-in and eye line visible before a talking-head clip is supplied.
const Conductor: React.FC<{frame: number}> = ({frame}) => (
  <svg viewBox="0 0 300 300" style={{height: '100%', width: '100%', display: 'block'}} aria-label="口播人物占位插画" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="booth" x2="1" y2="1" gradientUnits="objectBoundingBox" gradientTransform="scale(1)">
        <stop stopColor="#8eac9d"/><stop offset="1" stopColor="#3f736f"/>
      </linearGradient>
      <pattern id="booth-lines" width="7" height="7" patternUnits="userSpaceOnUse">
        <path d="M0 7L7 0" stroke="#f8e8ca" strokeWidth=".6" opacity=".2"/>
      </pattern>
    </defs>
    <rect width="300" height="300" fill="url(#booth)"/><rect width="300" height="300" fill="url(#booth-lines)"/>
    <circle cx="153" cy="145" r="111" fill="#d0c895" opacity=".59"/>
    <g transform={'translate(0 ' + 1.5 * Math.sin(frame / 12) + ')'}>
      <path d="M35 310Q42 253 70 237L123 213H178L230 239Q253 250 268 310" fill="#233f48"/>
      <path d="M112 220L145 274L188 223L166 209L131 208Z" fill="#e9d9b7"/>
      <path d="M139 244L154 242L161 252L151 287L140 259Z" fill="#a54e3f"/>
      <path d="M90 232L112 220L147 279L135 301L101 261L113 254Z M187 221L211 235L188 254L199 261L162 299L148 279Z" fill="#34565a"/>
      <path d="M128 189L131 217Q149 233 167 214L170 183" fill="#c58f68"/>
      <path d="M87 133Q79 98 91 82Q112 47 164 58Q213 65 212 121L199 174L108 173Z" fill="#293735"/>
      <path d="M98 130Q86 118 86 138Q88 154 101 157L110 184Q125 205 152 207Q177 207 193 179L201 151Q216 144 214 129Q212 122 203 125L201 101Q183 99 159 83Q141 102 106 111Z" fill="#e9b488"/>
      <path d="M105 122Q117 115 131 119M163 117Q181 112 192 119" fill="none" stroke="#463e36" strokeWidth="4.5" strokeLinecap="round"/>
      <g fill="none" stroke="#41433b" strokeWidth="4"><rect x="100" y="124" width="39" height="24" rx="10"/><rect x="158" y="122" width="39" height="24" rx="10"/><path d="M139 133Q147 127 158 132 M96 127L89 124M197 126L207 122"/></g>
      <path d="M148 134L144 157L151 159" fill="none" stroke="#b87958" strokeWidth="3.5" strokeLinecap="round"/>
      <g fill="#343832"><ellipse cx="121" cy="134" rx="3" ry="3.7"/><ellipse cx="174" cy="132" rx="3" ry="3.7"/></g>
      <path d={'M135 174Q149 ' + (177 + 1.8 * Math.sin(frame / 4)) + ' 166 169Q153 185 135 174Z'} fill="#945947"/>
      <path d="M79 94Q72 79 77 70Q92 47 130 40Q176 28 205 48Q216 59 213 70L196 87L108 104Z" fill="#334e52"/>
      <path d="M82 87Q139 62 205 64L202 79Q153 80 102 104Z" fill="#213638"/>
      <path d="M100 103Q156 73 205 79Q201 89 189 94Q146 91 112 107Q104 109 100 103Z" fill="#182f33"/>
      <path d="M89 88Q145 64 205 67" fill="none" stroke="#d2ac70" strokeWidth="3"/>
      <ellipse cx="155" cy="59" rx="8" ry="9" fill="#ddba7b"/><path d="M150 59H160M152 62H158" stroke="#486360" strokeWidth="2"/>
      <path d="M204 257L232 261" stroke="#d3b67e" strokeWidth="5" strokeLinecap="round"/>
    </g>
  </svg>
);

const Clip: React.FC<{src: string}> = ({src}) => <OffthreadVideo muted src={staticFile(src)} style={frameStyle} />;

export const PresenterCutaway: React.FC<typeof defaultCutaway> = ({photo, firstClip, secondClip, presenterVideo, side, punchIn, cue, sound}) => {
  const frame = useCurrentFrame();
  const photoIn = progress(frame, 4, 16);
  const pictureIsPhoto = frame < 48;
  const backdrop = '#152f32';
  const finalSide = frame < 75 ? (side === 'right' ? 'left' : side === 'left' ? 'right' : side === 'top' ? 'bottom' : 'top') : side;
  const vertical = finalSide === 'top' || finalSide === 'bottom';
  const scale = 1 + (punchIn - 1) * progress(frame, cue, cue + 16);
  const inset: React.CSSProperties = vertical
    ? {left: 925, top: finalSide === 'top' ? 60 : 396, width: 229, height: 229}
    : {left: finalSide === 'left' ? 87 : 904, top: 195, width: 289, height: 302};
  const cardStyle: React.CSSProperties = {position:'absolute', borderRadius: 22, boxShadow: shadow, overflow:'hidden'};
  const pictureX = pictureIsPhoto ? 207 : vertical ? 94 : finalSide === 'left' ? 432 : 88;
  const clip = frame < 60 || frame >= 75 ? firstClip : secondClip;
  return (
    <AbsoluteFill style={{background: backdrop, overflow: 'hidden', color: '#fff5e3', fontFamily: sans}}>
      <AbsoluteFill style={{transform: 'scale(1.15)', filter: 'blur(29px)', opacity: .5}}>
        <Img src={staticFile(photo)} style={frameStyle} />
      </AbsoluteFill>
      <AbsoluteFill style={{background:'linear-gradient(125deg, #17333b90, #1834354f 55%, #0b252bb8)'}}/>
      <div style={{...cardStyle, left: pictureX, width: pictureIsPhoto ? 866 : 760, height: pictureIsPhoto ? 494 : 434, top: pictureIsPhoto ? 110 : 143, padding: 5, boxSizing: 'border-box', background: 'linear-gradient(130deg,#f1dec4,#adb7a4 48%,#71908b)', transform: pictureIsPhoto ? 'translateY(' + ((1-photoIn)*30) + 'px) rotate(' + (-2.4*photoIn) + 'deg) scale(' + (.94+.06*photoIn) + ')' : undefined, opacity: pictureIsPhoto ? photoIn : 1}}>
        <div style={{height:'100%', width:'100%', overflow:'hidden', borderRadius:17}}>
          {pictureIsPhoto ? <Img src={staticFile(photo)} style={frameStyle}/> : <Clip src={clip}/>}
        </div>
      </div>
      {!pictureIsPhoto && <div style={{...cardStyle, ...inset, border:'3px solid #e4cfaa', background:'#4f7f79'}}>
        <div style={{width:'100%', height:'100%', transform: 'scale(' + scale + ')', transformOrigin: '50% 42%'}}>
          {presenterVideo ? <OffthreadVideo muted src={staticFile(presenterVideo)} style={frameStyle}/> : <Conductor frame={frame}/>}
        </div>
      </div>}
      {presenterVideo && <Html5Audio src={staticFile(presenterVideo)} />}
      {sound && <><Sound at={4} kind="photo"/>{[48,60,75].map(at=><Sound key={at} at={at} kind="cut" volume={.45}/>)}<Sound at={cue} kind="pop" volume={.48}/></>}
    </AbsoluteFill>
  );
};
