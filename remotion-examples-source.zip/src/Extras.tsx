import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const serif = '"Noto Serif SC", "STSong", "SimSun", serif';
const sans = '"Microsoft YaHei", "Noto Sans SC", sans-serif';
const mono = '"Consolas", monospace';
const shadow = '0 24px 60px rgba(4,10,12,.55), 0 4px 12px rgba(4,10,12,.35)';

const ease = (f: number, a: number, b: number) => {
  const t = interpolate(f, [a, b], [0, 1], clamp);
  return t * t * (3 - 2 * t);
};

/* ───────────────────────── 01 数据图表（柱状 / 环形 / KPI / 折线） ───────────────────────── */

const bars = [
  {label: '2021', value: 42},
  {label: '2022', value: 58},
  {label: '2023', value: 71},
  {label: '2024', value: 96},
  {label: '2025', value: 128},
];

const kpis = [
  {label: '营收', value: 128, unit: '亿'},
  {label: '增速', value: 63, unit: '%'},
  {label: '份额', value: 4.2, unit: '%', decimals: 1},
];

const DataBody: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cardIn = ease(frame, 0, 18);
  const barMax = 128;

  return (
    <AbsoluteFill style={{backgroundColor: '#0E1116', fontFamily: sans, color: '#F4EBDD', padding: 64, boxSizing: 'border-box'}}>
      {/* 背景：两支暖色光斑，慢慢漂移 */}
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(900px 520px at 18% 8%, #2a2018, transparent 62%), radial-gradient(760px 480px at 88% 92%, #16272a, transparent 60%)'}} />
      <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(115deg, rgba(232,163,61,.05), transparent 45%)', transform: `translateX(${Math.sin(frame / 46) * 26}px)`}} />

      {/* 卡片：无尖角 + 渐变交融 + 阴影 */}
      <div style={{
        position: 'relative', height: '100%', borderRadius: 30, padding: '34px 40px',
        background: 'linear-gradient(135deg, #F6EEE0 0%, #EFE3CD 52%, #E4D5BB 100%)',
        boxShadow: shadow, opacity: cardIn, transform: `translateY(${(1 - cardIn) * 26}px) scale(${0.97 + 0.03 * cardIn})`,
      }}>
        <div style={{position: 'absolute', inset: 0, borderRadius: 30, background: 'radial-gradient(120% 80% at 0% 0%, rgba(255,255,255,.55), transparent 55%)', pointerEvents: 'none'}} />

        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderBottom: '1px solid rgba(20,22,26,.14)', paddingBottom: 14}}>
          <div>
            <div style={{font: '600 11px ' + mono, letterSpacing: 3, color: '#9A7A48'}}>DATA / 2021—2025</div>
            <div style={{fontFamily: serif, fontWeight: 700, fontSize: 40, color: '#14161A', marginTop: 4}}>收入结构变了</div>
          </div>
          <div style={{fontFamily: serif, fontSize: 14, color: '#7A6A55'}}>来源：示例数据 · 需替换为你的 csv</div>
        </div>

        <div style={{display: 'flex', gap: 40, marginTop: 22}}>
          {/* KPI 数字滚动 */}
          <div style={{display: 'flex', flexDirection: 'column', gap: 14, width: 210}}>
            {kpis.map((k, i) => {
              const t = ease(frame, 12 + i * 8, 44 + i * 8);
              const v = k.value * t;
              return (
                <div key={k.label} style={{borderRadius: 18, padding: '12px 16px', background: 'linear-gradient(135deg, rgba(255,255,255,.72), rgba(255,255,255,.34))', boxShadow: '0 8px 18px rgba(60,40,20,.10)'}}>
                  <div style={{fontSize: 12, color: '#6D6152', letterSpacing: 2}}>{k.label}</div>
                  <div style={{fontFamily: serif, fontSize: 38, fontWeight: 700, color: '#14161A', lineHeight: 1.1}}>
                    {v.toFixed(k.decimals ?? 0)}<span style={{fontSize: 16, marginLeft: 4, color: '#9A7A48'}}>{k.unit}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* 柱状：错帧生长，最后一根高亮 */}
          <div style={{flex: 1, position: 'relative', display: 'flex', alignItems: 'flex-end', gap: 26, paddingTop: 10}}>
            {[0, 1, 2, 3].map((i) => (
              <div key={i} style={{position: 'absolute', left: 0, right: 0, bottom: 34 + i * 52, height: 1, background: 'rgba(20,22,26,.10)'}} />
            ))}
            {bars.map((b, i) => {
              const s = spring({frame: frame - (10 + i * 5), fps, config: {damping: 200, mass: 0.6}});
              const h = (b.value / barMax) * 74 * Math.max(0, s);
              const hot = i === bars.length - 1;
              return (
                <div key={b.label} style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', height: '100%'}}>
                  <div style={{fontFamily: serif, fontSize: 16, color: hot ? '#B4792C' : '#6D6152', opacity: s, marginBottom: 6}}>{b.value}</div>
                  <div style={{width: '74%', height: h + '%', borderRadius: '14px 14px 6px 6px', background: hot ? 'linear-gradient(180deg,#E8A33D,#C77E2A)' : 'linear-gradient(180deg,#4A5358,#2C3438)', boxShadow: hot ? '0 12px 26px rgba(232,163,61,.35)' : '0 8px 18px rgba(20,22,26,.18)'}} />
                  <div style={{font: '11px ' + mono, color: '#7A6A55', marginTop: 8, letterSpacing: 1}}>{b.label}</div>
                </div>
              );
            })}
          </div>

          {/* 环形：描边一圈，数字同步 */}
          <div style={{width: 250, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Ring />
          </div>
        </div>

        {/* 底部结论条 */}
        <div style={{position: 'absolute', left: 44, right: 44, bottom: 34, display: 'flex', alignItems: 'center', gap: 16, opacity: ease(frame, 52, 78), transform: `translateY(${(1 - ease(frame, 52, 78)) * 10}px)`}}>
          <div style={{width: 5, height: 42, borderRadius: 3, background: 'linear-gradient(180deg,#E8A33D,#C4562F)'}} />
          <div style={{fontFamily: serif, fontSize: 26, color: '#14161A', letterSpacing: 1}}>
            结论：线上收入 2025 年首次过半，结构已经变了。
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Ring: React.FC = () => {
  const frame = useCurrentFrame();
  const size = 168;
  const r = 70;
  const c = 2 * Math.PI * r;
  const t = ease(frame, 18, 62);
  const pct = 68 * t;
  return (
    <div style={{position: 'relative', width: size, height: size}}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#D6C7AE" strokeWidth={14} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="url(#g)" strokeWidth={14} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (c * 0.68 * t)} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#E8A33D" /><stop offset="100%" stopColor="#C4562F" />
          </linearGradient>
        </defs>
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{fontFamily: serif, fontSize: 38, fontWeight: 700, color: '#14161A', lineHeight: 1}}>{pct.toFixed(0)}<span style={{fontSize: 16}}>%</span></div>
        <div style={{fontSize: 11, color: '#6D6152', letterSpacing: 2, marginTop: 6}}>线上占比</div>
      </div>
    </div>
  );
};

/* ───────────────────────── 02 3D 侧视黑板（像坐第一排看黑板） ───────────────────────── */

const SideBoardBody: React.FC = () => {
  const frame = useCurrentFrame();
  const yaw = interpolate(frame, [0, 140], [-19, -13], {easing: Easing.inOut(Easing.cubic)});
  const lift = Math.sin(frame / 38) * 3;
  const nodes = ['痛点', '原因', '解法'];
  return (
    <AbsoluteFill style={{backgroundColor: '#0C1113', overflow: 'hidden', fontFamily: sans}}>
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(1000px 640px at 22% 18%, #1d2b29, transparent 60%), linear-gradient(160deg,#0d1416,#090d0f)'}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 190, background: 'linear-gradient(180deg, transparent, rgba(0,0,0,.55))'}} />

      <div style={{position: 'absolute', inset: 0, perspective: 1400, perspectiveOrigin: '38% 46%'}}>
        <div style={{
          position: 'absolute', left: 92, top: 92, width: 1060, height: 540,
          transform: `rotateY(${yaw}deg) rotateX(5deg) translateY(${lift}px)`,
          transformStyle: 'preserve-3d',
          borderRadius: 18,
          background: 'linear-gradient(135deg,#26332E,#1B2622 55%,#16201D)',
          boxShadow: '0 60px 120px rgba(0,0,0,.7), inset 0 0 90px rgba(0,0,0,.45)',
          border: '12px solid #6B4B33',
          boxSizing: 'border-box',
        }}>
          {/* 黑板粉笔网格 */}
          <div style={{position: 'absolute', inset: 0, opacity: .18, backgroundImage: 'linear-gradient(rgba(255,255,255,.22) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.22) 1px, transparent 1px)', backgroundSize: '68px 68px'}} />

          {/* 板书标题 */}
          <div style={{position: 'absolute', left: 46, top: 34, fontFamily: serif, fontSize: 40, color: '#F3EADA', letterSpacing: 3, textShadow: '0 2px 0 rgba(0,0,0,.4)'}}>
            为什么会这样
          </div>
          <div style={{position: 'absolute', left: 48, top: 96, height: 2, width: 260, background: 'rgba(243,234,218,.35)'}} />

          {/* 流程板书：节点逐个出现 + 箭头绘制 */}
          {nodes.map((n, i) => {
            const a = ease(frame, 24 + i * 26, 52 + i * 26);
            return (
              <div key={n} style={{position: 'absolute', left: 90 + i * 300, top: 250, opacity: a, transform: `translateY(${(1 - a) * 16}px)`}}>
                <div style={{
                  width: 196, height: 108, borderRadius: 22, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: i === 2 ? 'linear-gradient(135deg, rgba(232,163,61,.20), rgba(196,86,47,.14))' : 'rgba(243,234,218,.06)',
                  border: `2px solid ${i === 2 ? 'rgba(232,163,61,.75)' : 'rgba(243,234,218,.40)'}`,
                  boxShadow: i === 2 ? '0 0 40px rgba(232,163,61,.30)' : '0 10px 30px rgba(0,0,0,.35)',
                  fontFamily: serif, fontSize: 30, color: '#F3EADA', letterSpacing: 4,
                }}>{n}</div>
              </div>
            );
          })}

          {/* 箭头：虚线逐段画出 */}
          <svg width="100%" height="100%" style={{position: 'absolute', inset: 0}}>
            {[0, 1].map((i) => {
              const t = ease(frame, 60 + i * 22, 88 + i * 22);
              return (
                <g key={i} opacity={t}>
                  <line x1={292 + i * 300} y1={304} x2={292 + i * 300 + 58 * t} y2={304} stroke="#E8A33D" strokeWidth={3} strokeDasharray="8 8" />
                  <polygon points={`${350 + i * 300},304 ${340 + i * 300},298 ${340 + i * 300},310`} fill="#E8A33D" opacity={t} />
                </g>
              );
            })}
          </svg>

          {/* 粉笔字注解 */}
          <div style={{position: 'absolute', left: 92, top: 420, fontFamily: serif, fontSize: 19, color: 'rgba(243,234,218,.62)', opacity: ease(frame, 96, 120)}}>
            先有约束，再有选择；选择一变，结果就变。
          </div>
        </div>

        {/* 地板投影 */}
        <div style={{position: 'absolute', left: 150, bottom: 74, width: 980, height: 64, background: 'radial-gradient(closest-side, rgba(0,0,0,.55), transparent)', filter: 'blur(14px)'}} />
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── 03 圆形头像换位 ───────────────────────── */

const positions = {
  left: {left: 96, top: 226},
  right: {left: 986, top: 226},
  top: {left: 540, top: 54},
  bottom: {left: 540, top: 470},
};

export const CircleAvatarScene: React.FC<{photo?: string}> = ({photo}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const key = frame < 70 ? 'left' : frame < 108 ? 'right' : 'bottom';
  const to = positions[key as keyof typeof positions];
  const s = spring({frame: frame - (key === 'left' ? 0 : key === 'right' ? 70 : 108), fps, config: {damping: 22, mass: 0.7}});
  const appear = ease(frame, 0, 16);
  return (
    <AbsoluteFill style={{backgroundColor: '#101A1C', fontFamily: sans, color: '#F4EBDD'}}>
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(800px 500px at 70% 30%, #1B3033, transparent 62%)'}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: '46%', height: 1, background: 'rgba(244,235,221,.10)'}} />
      {/* 舞台中央的示意视频卡 */}
      <div style={{position: 'absolute', left: 372, top: 128, width: 536, height: 300, borderRadius: 26, background: 'linear-gradient(135deg,#28403F,#14282B)', boxShadow: shadow, display: 'flex', alignItems: 'center', justifyContent: 'center', letterSpacing: 4, color: 'rgba(244,235,221,.35)', fontSize: 13}}>
        A-ROLL / B-ROLL 画面区
      </div>
      {/* 头像 */}
      <div style={{
        position: 'absolute', width: 214, height: 214,
        left: to.left, top: to.top,
        opacity: appear,
        transform: `translate(${(1 - s) * (key === 'right' ? 40 : key === 'bottom' ? 0 : 0)}px, ${(1 - s) * 40}px) scale(${0.9 + 0.1 * s})`,
        borderRadius: '50%', padding: 6,
        background: 'linear-gradient(135deg,#F0DDBB,#E8A33D 45%,#9C6A2E)',
        boxShadow: '0 26px 60px rgba(0,0,0,.55), 0 0 0 1px rgba(255,255,255,.18) inset',
      }}>
        <div style={{width: '100%', height: '100%', borderRadius: '50%', overflow: 'hidden', background: 'linear-gradient(160deg,#3E6A66,#1C3536)'}}>
          {photo ? <img src={photo} style={{width: '100%', height: '100%', objectFit: 'cover'}} /> : (
            <div style={{width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: serif, fontSize: 34, color: 'rgba(255,255,255,.55)'}}>你</div>
          )}
        </div>
      </div>
    </AbsoluteFill>
  );
};

export {DataBody, SideBoardBody};
