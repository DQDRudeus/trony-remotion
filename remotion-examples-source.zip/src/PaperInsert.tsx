export {PaperInsert} from './TronyPaper';
export type {PaperInsertProps} from './TronyPaper';
