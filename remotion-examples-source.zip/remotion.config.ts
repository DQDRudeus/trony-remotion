import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {Config} from '@remotion/cli/config';

// Reuse an installed browser on Windows. Elsewhere the CLI manages its own browser.
if (process.platform === 'win32') {
  const candidates = [
    join(process.env.ProgramFiles ?? 'C:/Program Files', 'Google/Chrome/Application/chrome.exe'),
    join(process.env['ProgramFiles(x86)'] ?? 'C:/Program Files (x86)', 'Microsoft/Edge/Application/msedge.exe'),
  ];
  const installed = candidates.find(path => existsSync(path));
  if (installed) Config.setBrowserExecutable(installed);
}
